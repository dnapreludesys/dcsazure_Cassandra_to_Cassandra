import azure.functions as func
import azure.durable_functions as df
import logging
import json
import pandas as pd
import uuid
from datetime import datetime
from io import StringIO
from collections import defaultdict, deque

from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider

from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
from azure.storage.filedatalake import DataLakeServiceClient


app = df.DFApp(http_auth_level=func.AuthLevel.ANONYMOUS)

# ============================================================
# Key Vault (Managed Identity)
# ============================================================
def get_kv_secret(vault_name, secret_name):
    client = SecretClient(
        vault_url=f"https://{vault_name}.vault.azure.net/",
        credential=DefaultAzureCredential()
    )
    return client.get_secret(secret_name).value.strip()


# ============================================================
# JSON column detection (PATCH)
# ============================================================
def detect_all_json_columns(row_dict):
    cols = []
    for k, v in row_dict.items():
        if isinstance(v, (dict, list)):
            cols.append(k)
        elif isinstance(v, str):
            try:
                parsed = json.loads(v)
                if isinstance(parsed, (dict, list)):
                    cols.append(k)
            except Exception:
                pass
    return cols


# ============================================================
# Flatten helpers (UNCHANGED)
# ============================================================
def flatten_keep_lists(d, parent=""):
    flat = {}
    for k, v in d.items():
        key = f"{parent}.{k}" if parent else k
        if isinstance(v, list):
            flat[key] = v
        elif isinstance(v, dict):
            flat.update(flatten_keep_lists(v, key))
        else:
            flat[key] = v
    return flat


def extract_arrays_iterative_optimized(doc):
    parent = {}
    children = {}

    root_rid = str(uuid.uuid4())
    doc["_rid"] = root_rid

    flat_root = flatten_keep_lists(doc)
    queue = deque()

    for key, value in flat_root.items():
        if not isinstance(value, list):
            parent[key] = value
            continue

        dict_items = [v for v in value if isinstance(v, dict)]
        prim_items = [v for v in value if not isinstance(v, dict)]

        if prim_items and not dict_items:
            parent[key] = value
            continue

        for item in dict_items:
            item["_rid"] = str(uuid.uuid4())
            item["_parent_rid"] = root_rid
            queue.append((item, key, root_rid))

    while queue:
        current, table_name, parent_rid = queue.popleft()
        flat_child = flatten_keep_lists(current)

        row = {"_rid": current["_rid"], "_parent_rid": parent_rid}

        for k, v in flat_child.items():
            col = k.split(".")[-1]
            if not isinstance(v, list):
                row[col] = v
                continue

            dict_items = [x for x in v if isinstance(x, dict)]
            prim_items = [x for x in v if not isinstance(x, dict)]

            if prim_items and not dict_items:
                row[col] = v
                continue

            for itm in dict_items:
                itm["_rid"] = str(uuid.uuid4())
                itm["_parent_rid"] = current["_rid"]
                queue.append((itm, f"{table_name}.{col}", current["_rid"]))

        children.setdefault(table_name, []).append(row)

    return parent, children


# ============================================================
# ADLS append + flush (UNCHANGED)
# ============================================================
def append_csv_batch(fs, dir_path, file_name, rows, state, include_header):
    if not rows:
        return

    df = pd.DataFrame(rows)

    for c in df.columns:
        df[c] = df[c].apply(
            lambda v: json.dumps(v, ensure_ascii=False)
            if isinstance(v, (dict, list))
            else ("" if v is None else v)
        )

    buf = StringIO()
    df.to_csv(buf, sep="|", index=False, header=include_header)
    data = buf.getvalue().encode("utf-8")
    size = len(data)

    file_client = fs.get_directory_client(dir_path).get_file_client(file_name)
    file_client.append_data(data, state["offset"], size)
    state["offset"] += size
    file_client.flush_data(state["offset"])


# ============================================================
# ACTIVITY
# ============================================================
@app.activity_trigger(input_name="params")
def cassandra_flatten_activity(params):
    start = datetime.utcnow()

    try:
        password = get_kv_secret(
            params["Cassandra_key_vault_name"],
            params["Cassandra_key_vault_secret_name"]
        )

        hosts = [h.strip() for h in params["cassandra_contact_points"].split(",")]
        cluster = Cluster(
            hosts,
            port=int(params.get("cassandra_port", 9042)),
            auth_provider=PlainTextAuthProvider(
                params["cassandra_username"], password
            )
        )

        session = cluster.connect()
        query = f"SELECT * FROM {params['cassandra_keyspace']}.{params['cassandra_table']}"

        adls = DataLakeServiceClient(
            account_url=f"https://{params['adls_account_name']}.dfs.core.windows.net",
            credential=DefaultAzureCredential()
        )
        fs = adls.get_file_system_client(params["adls_file_system"])

        base_dir = f"{params.get('adls_directory','').strip('/')}/{params['cassandra_table']}".strip("/")
        try:
            fs.get_directory_client(base_dir).create_directory()
        except Exception:
            pass

        parent_file = f"{params['cassandra_table']}.csv"
        try:
            fs.get_directory_client(base_dir).create_file(parent_file)
        except Exception:
            pass

        batch_size = int(params.get("adls_batch_size", 1000))
        parent_state = {"offset": 0, "first": True}
        child_state = {}
        parent_buffer = []
        child_buffers = defaultdict(list)

        # ====================================================
        # STREAMING LOOP (PATCHED)
        # ====================================================
        for row in session.execute(query):
            rd = row._asdict()
            parent_row = {}

            json_cols = detect_all_json_columns(rd)

            for json_col in json_cols:
                raw = rd.get(json_col)
                parsed = json.loads(raw) if isinstance(raw, str) else raw or {}

                parent_doc, children = extract_arrays_iterative_optimized(parsed)

                for k, v in parent_doc.items():
                    parent_row[f"{json_col}.{k}"] = v

                for tbl, rows_list in children.items():
                    scoped = f"{json_col}.{tbl}"
                    child_buffers[scoped].extend(rows_list)

            for k, v in rd.items():
                if k not in json_cols:
                    parent_row[k] = v

            parent_buffer.append(parent_row)

            # ---------------- FLUSH ----------------
            if len(parent_buffer) >= batch_size:
                append_csv_batch(
                    fs, base_dir, parent_file,
                    parent_buffer, parent_state, parent_state["first"]
                )
                parent_state["first"] = False
                parent_buffer.clear()

                for tbl, rows_list in child_buffers.items():
                    parts = tbl.split(".")
                    dir_path = f"{base_dir}/{'/'.join(parts[:-1])}"
                    file_name = f"{parts[-1]}.csv"

                    if tbl not in child_state:
                        child_state[tbl] = {"offset": 0, "first": True}
                        try:
                            fs.get_directory_client(dir_path).create_directory()
                        except Exception:
                            pass
                        try:
                            fs.get_directory_client(dir_path).create_file(file_name)
                        except Exception:
                            pass

                    append_csv_batch(
                        fs, dir_path, file_name,
                        rows_list,
                        child_state[tbl],
                        child_state[tbl]["first"]
                    )
                    child_state[tbl]["first"] = False

                child_buffers.clear()

        # ---------------- FINAL FLUSH ----------------
        append_csv_batch(
            fs, base_dir, parent_file,
            parent_buffer, parent_state, parent_state["first"]
        )

        for tbl, rows_list in child_buffers.items():
            parts = tbl.split(".")
            dir_path = f"{base_dir}/{'/'.join(parts[:-1])}"
            file_name = f"{parts[-1]}.csv"

            if tbl not in child_state:
                child_state[tbl] = {"offset": 0, "first": True}
                fs.get_directory_client(dir_path).create_directory()
                fs.get_directory_client(dir_path).create_file(file_name)

            append_csv_batch(
                fs, dir_path, file_name,
                rows_list,
                child_state[tbl],
                child_state[tbl]["first"]
            )

        session.shutdown()
        cluster.shutdown()

        return {
            "status": "success",
            "duration_seconds": (datetime.utcnow() - start).total_seconds()
        }

    except Exception as e:
        logging.exception("Flatten failed")
        return {"status": "error", "message": str(e)}


# ============================================================
# ORCHESTRATOR
# ============================================================
@app.orchestration_trigger(context_name="context")
def cassandra_flatten_orchestrator(context):
    result = yield context.call_activity(
        "cassandra_flatten_activity",
        context.get_input()
    )
    return result


# ============================================================
# HTTP START
# ============================================================
@app.route(route="Cassandra_to_ADLS_Flatten", methods=["POST"])
@app.durable_client_input(client_name="client")
async def cassandra_flatten_http_start(req: func.HttpRequest, client):
    instance_id = await client.start_new(
        "cassandra_flatten_orchestrator",
        None,
        req.get_json()
    )
    return client.create_check_status_response(req, instance_id)
