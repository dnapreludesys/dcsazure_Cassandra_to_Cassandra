import azure.functions as func
import azure.durable_functions as df
import json
import pandas as pd
import uuid
from datetime import datetime
from io import StringIO
from collections import defaultdict
from typing import Dict, Any, List

from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider
from cassandra.query import SimpleStatement, dict_factory
from cassandra import ConsistencyLevel

from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
from azure.storage.filedatalake import DataLakeServiceClient

# ============================================================
# Function App
# ============================================================
app = func.FunctionApp()

# ============================================================
# Key Vault helper
# ============================================================
def get_kv_secret(vault_name: str, secret_name: str) -> str:
    vault_url = f"https://{vault_name.strip()}.vault.azure.net/"
    client = SecretClient(vault_url=vault_url, credential=DefaultAzureCredential())
    return client.get_secret(secret_name.strip()).value

# ============================================================
# Normalize partition values (UUID / INT / STRING safe)
# ============================================================
def normalize_partition_values(values):
    normalized = []
    for v in values:
        if isinstance(v, str):
            try:
                normalized.append(uuid.UUID(v))
                continue
            except Exception:
                pass
        normalized.append(v)
    return normalized

# ============================================================
# Detect JSON columns
# ============================================================
def detect_json_columns(row: Dict[str, Any]) -> List[str]:
    return [k for k, v in row.items() if isinstance(v, (dict, list))]

# ============================================================
# Extract JSON arrays
# ============================================================
def extract_json_arrays(doc: Dict[str, Any], parent_rid: str, prefix: str):
    arrays = defaultdict(list)

    def walk(obj, path, current_parent):
        if isinstance(obj, list):
            array_path = f"{prefix}/{path}".strip("/")
            for item in obj:
                rid = str(uuid.uuid4())
                row = {"_rid": rid, "_parent_rid": current_parent}

                if isinstance(item, dict):
                    for k, v in item.items():
                        if not isinstance(v, (dict, list)):
                            row[k] = v
                    arrays[array_path].append(row)

                    for k, v in item.items():
                        if isinstance(v, (dict, list)):
                            walk(v, f"{path}/{k}".strip("/"), rid)
                else:
                    row["value"] = item
                    arrays[array_path].append(row)

        elif isinstance(obj, dict):
            for k, v in obj.items():
                walk(v, f"{path}/{k}".strip("/"), current_parent)

    walk(doc, "", parent_rid)
    return arrays

# ============================================================
# CSV writer
# ============================================================
def append_csv(fs, directory, file_name, rows, offset, include_header):
    if not rows:
        return

    df_data = pd.DataFrame(rows)

    for c in df_data.columns:
        df_data[c] = df_data[c].apply(
            lambda v: json.dumps(v, ensure_ascii=False)
            if isinstance(v, (dict, list))
            else ("" if v is None else v)
        )

    buf = StringIO()
    df_data.to_csv(buf, sep="|", index=False, header=include_header)

    data = buf.getvalue().encode("utf-8")
    size = len(data)

    file_client = fs.get_directory_client(directory).get_file_client(file_name)
    file_client.append_data(data, offset["offset"], size)
    offset["offset"] += size
    file_client.flush_data(offset["offset"])

# ============================================================
# ACTIVITY FUNCTION
# ============================================================
@app.activity_trigger(input_name="params")
def cassandra_to_adls_activity(params: dict):
    start = datetime.utcnow()
    cluster = None
    session = None

    try:
        table = params["cassandra_table"]
        keyspace = params["cassandra_keyspace"]

        cassandra_username = params["cassandra_username"]

        if params.get("Cassandra_key_vault_name"):
            cassandra_password = get_kv_secret(
                params["Cassandra_key_vault_name"],
                params["Cassandra_key_vault_secret_name"]
            )
        else:
            cassandra_password = params["cassandra_password"]

        # 🔹 NO port hard-coding
        cluster = Cluster(
            params["cassandra_contact_points"].split(","),
            auth_provider=PlainTextAuthProvider(
                cassandra_username,
                cassandra_password
            )
        )

        session = cluster.connect(keyspace)
        session.row_factory = dict_factory
        session.default_timeout = 60

        # ====================================================
        # OPTIONAL PARTITION KEY LOGIC
        # ====================================================
        partition_key = params.get("partition_key")
        partition_values = params.get("partition_values")

        rows = []

        if partition_key and isinstance(partition_values, list) and partition_values:
            partition_values = normalize_partition_values(partition_values)

            stmt = SimpleStatement(
                f"SELECT * FROM {table} WHERE {partition_key} = %s",
                consistency_level=ConsistencyLevel.LOCAL_ONE
            )

            for pv in partition_values:
                rows.extend(list(session.execute(stmt, [pv])))

        else:
            stmt = SimpleStatement(
                f"SELECT * FROM {table}",
                consistency_level=ConsistencyLevel.LOCAL_ONE
            )
            rows = list(session.execute(stmt))

        if not rows:
            return {
                "status": "success",
                "message": "No rows returned from Cassandra",
                "duration_seconds": (datetime.utcnow() - start).total_seconds()
            }

        # ====================================================
        # ADLS
        # ====================================================
        adls = DataLakeServiceClient(
            account_url=f"https://{params['adls_account_name']}.dfs.core.windows.net",
            credential=DefaultAzureCredential()
        )

        fs = adls.get_file_system_client(params["adls_file_system"])
        base_dir = f"{params.get('adls_directory','')}/{table}".strip("/")
        fs.get_directory_client(base_dir).create_directory()

        parent_file = f"{table}.csv"
        fs.get_directory_client(base_dir).create_file(parent_file)

        parent_offset = {"offset": 0}
        parent_first = True
        child_offsets = {}
        child_first = {}
        json_cols = None

        for row in rows:
            if json_cols is None:
                json_cols = detect_json_columns(row)

            parent_rid = str(uuid.uuid4())
            parent_row = {"_rid": parent_rid}

            for k, v in row.items():
                if k not in json_cols:
                    parent_row[k] = v

            append_csv(fs, base_dir, parent_file, [parent_row], parent_offset, parent_first)
            parent_first = False

            for jc in json_cols:
                value = row.get(jc)
                if not value:
                    continue

                arrays = extract_json_arrays(value, parent_rid, jc)

                for array_path, records in arrays.items():
                    dir_path = f"{base_dir}/{array_path}"
                    fs.get_directory_client(dir_path).create_directory()

                    file_name = f"{array_path.split('/')[-1]}.csv"
                    key = f"{dir_path}/{file_name}"

                    if key not in child_offsets:
                        fs.get_directory_client(dir_path).create_file(file_name)
                        child_offsets[key] = {"offset": 0}
                        child_first[key] = True

                    append_csv(
                        fs,
                        dir_path,
                        file_name,
                        records,
                        child_offsets[key],
                        child_first[key]
                    )
                    child_first[key] = False

        return {
            "status": "success",
            "row_count": len(rows),
            "duration_seconds": (datetime.utcnow() - start).total_seconds()
        }

    finally:
        if session:
            session.shutdown()
        if cluster:
            cluster.shutdown()

# ============================================================
# ORCHESTRATOR
# ============================================================
@app.orchestration_trigger(context_name="context")
def cassandra_to_adls_orchestrator(context: df.DurableOrchestrationContext):
    result = yield context.call_activity(
        "cassandra_to_adls_activity",
        context.get_input()
    )
    return result

# ============================================================
# HTTP STARTER
# ============================================================
@app.route(route="Cassandra_to_ADLS_Flatten", methods=["POST"])
@app.durable_client_input(client_name="client")
async def cassandra_to_adls_http_start(req: func.HttpRequest, client):
    instance_id = await client.start_new(
        "cassandra_to_adls_orchestrator",
        None,
        req.get_json()
    )
    return client.create_check_status_response(req, instance_id)
