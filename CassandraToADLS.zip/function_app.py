import azure.functions as func
import azure.durable_functions as df
import json
import logging
import pandas as pd
import uuid
import gc
from datetime import datetime
from io import StringIO
from collections import deque
from typing import Dict, Any, Optional

from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider
from cassandra.query import SimpleStatement
from azure.storage.filedatalake import DataLakeServiceClient

app = df.DFApp(http_auth_level=func.AuthLevel.ANONYMOUS)

# ============================================================
# Utility helpers
# ============================================================
def clean_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame()

    def fix(v):
        if v is None:
            return None
        if isinstance(v, (str, int, float, bool)):
            return v
        if isinstance(v, list) and all(not isinstance(i, dict) for i in v):
            return v
        return None

    for c in df.columns:
        df[c] = df[c].apply(fix)
    return df


def append_csv_to_adls(fs, directory, file_name, df, offset, include_header):
    df = clean_dataframe(df)
    if df.empty:
        return

    df_out = df.copy()
    for c in df_out.columns:
        df_out[c] = df_out[c].apply(
            lambda v: json.dumps(v, ensure_ascii=False)
            if isinstance(v, list) else ("" if v is None else v)
        )

    buf = StringIO()
    df_out.to_csv(buf, sep="|", index=False, header=include_header)

    data = buf.getvalue().encode("utf-8")
    size = len(data)

    file_client = fs.get_directory_client(directory).get_file_client(file_name)
    file_client.append_data(data, offset["offset"], size)
    offset["offset"] += size
    file_client.flush_data(offset["offset"])


# ============================================================
# JSON flatten + array extraction (FINAL)
# ============================================================
def extract_arrays_iterative_optimized(doc: Dict[str, Any]):
    parent = {}
    children = {}

    root_rid = str(uuid.uuid4())
    doc["_rid"] = root_rid
    queue = deque()

    def flatten_obj(obj, prefix=""):
        out = {}
        for k, v in obj.items():
            key = f"{prefix}.{k}" if prefix else k
            if isinstance(v, dict):
                out.update(flatten_obj(v, key))
            else:
                out[key] = v
        return out

    flat_root = flatten_obj(doc)

    for k, v in flat_root.items():
        if not isinstance(v, list):
            parent[k] = v
            continue

        dict_items = [x for x in v if isinstance(x, dict)]
        prim_items = [x for x in v if not isinstance(x, dict)]

        if prim_items and not dict_items:
            parent[k] = v
            continue

        for item in dict_items:
            item["_rid"] = str(uuid.uuid4())
            item["_parent_rid"] = root_rid
            queue.append((item, k, root_rid))

    batch = {}

    while queue:
        current, table_name, parent_rid = queue.popleft()
        flat = flatten_obj(current)

        row = {
            "_rid": current["_rid"],
            "_parent_rid": parent_rid
        }

        for k, v in flat.items():
            if not isinstance(v, list):
                row[k] = v
                continue

            dict_items = [x for x in v if isinstance(x, dict)]
            prim_items = [x for x in v if not isinstance(x, dict)]

            if prim_items and not dict_items:
                row[k] = v
                continue

            for item in dict_items:
                item["_rid"] = str(uuid.uuid4())
                item["_parent_rid"] = current["_rid"]
                queue.append((item, f"{table_name}.{k}", current["_rid"]))

        batch.setdefault(table_name, []).append(row)

        if len(batch[table_name]) >= 100:
            children.setdefault(table_name, []).append(pd.DataFrame(batch[table_name]))
            batch[table_name] = []

    for t, rows in batch.items():
        if rows:
            children.setdefault(t, []).append(pd.DataFrame(rows))

    return parent, {
        k: pd.concat(v, ignore_index=True)
        for k, v in children.items()
    }


# ============================================================
# JSON column detection
# ============================================================
def detect_json_column(rows) -> Optional[str]:
    for c in rows[0]._asdict().keys():
        val = rows[0]._asdict().get(c)
        if isinstance(val, (dict, list)):
            return c
        if isinstance(val, str):
            try:
                json.loads(val)
                return c
            except Exception:
                pass
    return None


# ============================================================
# ACTIVITY FUNCTION
# ============================================================
@app.activity_trigger(input_name="params")
def cassandra_to_adls_activity(params: dict):
    start = datetime.utcnow()

    batch_size = int(params["adls_batch_size"])
    table = params["cassandra_table"]

    cluster = Cluster(
        params["cassandra_contact_points"].split(","),
        auth_provider=PlainTextAuthProvider(
            params["cassandra_username"],
            params["cassandra_password"]
        )
    )
    session = cluster.connect()

    query = f"SELECT * FROM {params['cassandra_keyspace']}.{table}"
    stmt = SimpleStatement(query, fetch_size=batch_size)
    rows = session.execute(stmt)

    adls = DataLakeServiceClient(
        account_url=f"https://{params['adls_account_name']}.dfs.core.windows.net",
        credential=params["adls_account_key"]
    )
    fs = adls.get_file_system_client(params["adls_file_system"])

    export_dir = f"{params.get('adls_directory','')}/{table}".strip("/")
    fs.get_directory_client(export_dir).create_directory()

    parent_file = f"{table}.csv"
    fs.get_directory_client(export_dir).create_file(parent_file)

    parent_offset = {"offset": 0}
    parent_first = True

    child_offsets = {}
    child_first = {}

    parents = []
    children_buf = {}

    json_col = None
    rows_copied = 0
    batches = 0

    for r in rows:
        if json_col is None:
            json_col = detect_json_column([r])
            if not json_col:
                raise Exception("JSON column not detected")

        raw = r._asdict().get(json_col)
        parsed = json.loads(raw) if isinstance(raw, str) else raw or {}

        p, c = extract_arrays_iterative_optimized(parsed)

        # ---- MERGE CASSANDRA + JSON (CRITICAL FIX) ----
        parent_row = {}
        for col, val in r._asdict().items():
            if col != json_col:
                parent_row[col] = val

        for k, v in p.items():
            parent_row[f"{json_col}.{k}"] = v

        parents.append(parent_row)
        rows_copied += 1

        for name, df in c.items():
            full_name = f"{json_col}.{name}"
            children_buf.setdefault(full_name, []).append(df)

        if len(parents) == batch_size:
            batches += 1

            append_csv_to_adls(
                fs, export_dir, parent_file,
                pd.DataFrame(parents),
                parent_offset,
                parent_first
            )
            parent_first = False
            parents.clear()

            for name, dfs in children_buf.items():
                merged = pd.concat(dfs, ignore_index=True)
                child_dir = f"{export_dir}/{'/'.join(name.split('.'))}"
                fs.get_directory_client(child_dir).create_directory()
                child_file = f"{name.split('.')[-1]}.csv"

                if name not in child_offsets:
                    child_offsets[name] = {"offset": 0}
                    child_first[name] = True
                    fs.get_directory_client(child_dir).create_file(child_file)

                append_csv_to_adls(
                    fs, child_dir, child_file,
                    merged,
                    child_offsets[name],
                    child_first[name]
                )
                child_first[name] = False

            children_buf.clear()
            gc.collect()

    if parents:
        append_csv_to_adls(
            fs, export_dir, parent_file,
            pd.DataFrame(parents),
            parent_offset,
            parent_first
        )

    session.shutdown()
    cluster.shutdown()

    return {
        "status": "success",
        "rows_copied": rows_copied,
        "batches_completed": batches,
        "duration_seconds": (datetime.utcnow() - start).total_seconds()
    }


# ============================================================
# ORCHESTRATOR
# ============================================================
@app.orchestration_trigger(context_name="context")
def cassandra_to_adls_orchestrator(context: df.DurableOrchestrationContext):
    result = yield context.call_activity(
        "cassandra_to_adls_activity",
        context.get_input()
    )
    return result


# ============================================================
# HTTP START
# ============================================================
@app.route(route="Cassandra_to_ADLS_Flatten", methods=["POST"])
@app.durable_client_input(client_name="client")
async def cassandra_to_adls_http_start(req: func.HttpRequest, client):
    instance_id = await client.start_new(
        "cassandra_to_adls_orchestrator",
        None,
        req.get_json()
    )
    return client.create_check_status_response(req, instance_id)
