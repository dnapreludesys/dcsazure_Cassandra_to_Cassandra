# dcsazure_Cassandra_to_Cassandra_discovery_pl
## Delphix Compliance Services (DCS) for Azure - Cassandra to Cassandra Discovery Pipeline

This pipeline will perform automated sensitive data discovery on your Cassandra Instance.

### Prerequisites
1. Configure the hosted metadata database and associated Azure SQL service (version `V2025.01.15.0`+).
1. Configure the DCS for Azure REST service.
1. Configure the Cassandra linked service.
  * It is helpful for the linked service to be parameterized with the following parameters:
    * `LS_DATABASE` - this is the database name in the linked service
    * `LS_WAREHOUSE` - this is the warehouse name in the linked service
    * `LS_ROLE` - this is the role the linked service should use
1. Configure the Blob Storage linked service to the container named `staging-container`.

### Importing
There are several linked services that will need to be selected in order to perform the profiling and data discovery of
your Cassandra instance.

These linked services types are needed for the following steps:

`Azure Function` (Cassandra to ADLS) – Linked service associated with exporting Cassandra data to ADLS. This will be used for the following steps:

Cassandra to ADLS (Azure Function activity)

`Azure Blob Storage` (staging) - Linked service associated with a blob storage container that can be used to stage data
when performing a data copy from Cassandra. This will be used for the following steps:
* Schema Discovery From Cassandra (Copy data activity)

`Cassandra` (source) - Linked service associated with unmasked Cassandra data. This will be used for the following
steps:
* dcsazure_Cassandra_to_Cassandra_discovery_source_ds (Cassandra dataset)
* dcsazure_Cassandra_to_Cassandra_data_discovery_df/Source1MillRowDataSampling (dataFlow)

`Azure SQL` (metadata) - Linked service associated with your hosted metadata store. This will be used for the following
steps:
* Update Discovery State (Stored procedure activity)
* Update Discovery State Failed (Stored procedure activity)
* Check If We Should Rediscover Data (If Condition activity)
* dcsazure_Cassandra_to_Cassandra_discovery_metadata_ds (Azure SQL Database dataset)
* dcsazure_Cassandra_to_Cassandra_data_discovery_df/MetadataStoreRead (dataFlow)
* dcsazure_Cassandra_to_Cassandra_data_discovery_df/WriteToMetadataStore (dataFlow)

`REST` (DCS for Azure) - Linked service associated with calling DCS for Azure. This will be used for the following
steps:
* dcsazure_Cassandra_to_Cassandra_data_discovery_df (dataFlow)

### How It Works
The discovery pipeline has a few stages:
* Check If We Should Rediscover Data
  * If we should, Mark Tables Undiscovered. This is done by updating the metadata store to indicate that tables
    have not had their sensitive data discovered
* Schema Discovery From Cassandra
  * Query metadata from Cassandra `information_schema` to identify tables and columns in the Cassandra instance
* Select Discovered Tables
  * After persisting the metadata to the metadata store, collect the list of discovered tables
* For Each Discovered Table
  * Call the `dcsazure_Cassandra_to_Cassandra_data_discovery_df` data flow


### Variables

If you have configured your database using the metadata store scripts, these variables will not need editing. If you
have customized your metadata store, then these variables may need editing.

* `METADATA_SCHEMA` - This is the schema to be used for in the self-hosted AzureSQL database for storing metadata
  (default `dbo`)
* `METADATA_RULESET_TABLE` - This is the table to be used for storing the discovered ruleset
  (default `discovered_ruleset`)
* `DATASET` - This is used to identify data that belongs to this pipeline in the metadata store (default `CASSANDRA`)
* `METADATA_EVENT_PROCEDURE_NAME` - This is the name of the procedure used to capture pipeline information in the
  metadata data store and sets the discovery state on the items discovered during execution
  (default `insert_adf_discovery_event`).
* `NUMBER_OF_ROWS_TO_PROFILE` - This is the number of rows we should select for profiling, note that raising this value
  could cause requests to fail (default `1000`).
* `COLUMNS_FROM_ADLS_FILE_STRUCTURE_PROCEDURE_NAME` - Stored procedure used to derive column metadata from ADLS file structures.  
  Default: get_columns_from_delimited_file_structure_sp.
* `STORAGE_ACCOUNT` -  Azure Storage account name used during metadata discovery.Default: dcscassandra.
* `BATCH_SIZE` –  Number of records to be processed per batch during data extraction operations to ADLS.
* `CASSANDRA_KEY_VAULT_NAME` –  Name of the Azure Key Vault that stores the Cassandra DB access key
* `CASSANDRA_SECRET_NAME` – Name of the secret in Key Vault containing the Cassandra DB access key



### Parameters

* `P_CASSANDRA_CONTACT_POINTS` - String - Hostname or IP address(es) of the Cassandra node(s) used to establish the initial connection to the cluster.
* `P_CASSANDRA_PORT` - Int - Port number on which the Cassandra service is listening.
* `P_CASSANDRA_USERNAME` - String - Username used to authenticate against the Cassandra cluster.
* `P_CASSANDRA_KEYSPACE` - String - Cassandra keyspace that contains the target table.
* `P_CASSANDRA_TABLE` - String - Name of the Cassandra table to be read from or written to.
* `P_CASSANDRA_PREFERRED` - String - Preferred Cassandra node (IP or hostname) for node-specific read or write operations.
* `P_CASSANDRA_PREFERRED_PORT` - Int - Preferred port number of the Cassandra node to be used for node-specific read operations.
* `P_CASSANDRA_PARTITION_KEY` - String - Partition key value used to control data distribution and node-level reads/writes.
* `P_CASSANDRA_PARTITION_VALUE` - String - Partition key value to filter and process a specific subset of records.
* `P_ADLS_SOURCE_CONTAINER_NAME` - String - ADLS container name where data will be written or read.
* `P_REDISCOVER` - Bool - Flag to indicate whether metadata discovery or rediscovery should be performed for the Cassandra source.
* `P_COPY_CASSANDRA_DATA_TO_ADLS` - Bool - Specifies whether data should be copied from Cassandra DB to ADLS (default `true`)
