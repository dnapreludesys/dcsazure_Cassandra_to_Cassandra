import azure.functions as func
import azure.durable_functions as df
import logging
import json
import uuid
from datetime import datetime
from io import StringIO
from typing import Any, Dict, List

import pandas as pd
from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider
from azure.storage.filedatalake import DataLakeServiceClient


app = df.DFApp(http_auth_level=func.AuthLevel.ANONYMOUS)


# ============================================================
#                     ADLS HELPERS
# ============================================================
def get_service_client(account_name: str, account_key: str) -> DataLakeServiceClient:
    return DataLakeServiceClient(
        account_url=f"https://{account_name}.dfs.core.windows.net",
        credential=account_key
    )


def read_csv_from_adls(service_client, file_system, path, sep="|") -> pd.DataFrame:
    fs = service_client.get_file_system_client(file_system)
    f = fs.get_file_client(path)
    content = f.download_file().readall().decode("utf-8")
    return pd.read_csv(StringIO(content), sep=sep, dtype=str).fillna("")


def list_paths_in_directory(service_client, file_system, directory) -> List[str]:
    fs = service_client.get_file_system_client(file_system)
    return [
        p.name for p in fs.get_paths(path=directory, recursive=True)
        if not getattr(p, "is_directory", False)
    ]


# ============================================================
#            AUTO JSON COLUMN DETECTION
# ============================================================
def detect_json_column_from_parent(df: pd.DataFrame) -> str:
    dotted = [c for c in df.columns if "." in c]
    if dotted:
        roots = [c.split(".")[0] for c in dotted]
        return max(set(roots), key=roots.count)
    return df.columns[-1]


# ============================================================
#            NESTING / NORMALIZATION HELPERS
# ============================================================
def normalize_block_path(path: str) -> str:
    if not path:
        return ""
    parts = [p for p in path.split(".") if p]

    cleaned = []
    for p in parts:
        if not cleaned or cleaned[-1] != p:
            cleaned.append(p)

    parts = cleaned

    changed = True
    while changed:
        changed = False
        n = len(parts)
        for bl in range(n // 2, 0, -1):
            i = 0
            while i + 2*bl <= n:
                if parts[i:i+bl] == parts[i+bl:i+2*bl]:
                    del parts[i+bl:i+2*bl]
                    changed = True
                    break
                i += 1
            if changed:
                break

    return ".".join(parts)


def set_nested(obj: Dict[str, Any], path_list: List[str], value: Any):
    cur = obj
    for i, p in enumerate(path_list):
        if i == len(path_list) - 1:
            cur[p] = value
        else:
            if p not in cur or not isinstance(cur[p], dict):
                cur[p] = {}
            cur = cur[p]


# ============================================================
#                CASSANDRA TYPE CASTING
# ============================================================
def parse_bool(value):
    if value in (None, ""):
        return None
    return str(value).lower() in ("true", "1", "yes", "y")


def parse_timestamp(value):
    if value in (None, ""):
        return None
    s = str(value).strip()
    try:
        if s.endswith("Z"):
            s = s.replace("Z", "+00:00")
        return datetime.fromisoformat(s)
    except:
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
            try:
                return datetime.strptime(s, fmt)
            except:
                pass
    return None


def cast_value_by_cass_type(value: Any, cass_type: str):
    if value in (None, ""):
        return None
    t = cass_type.lower()

    try:
        if "uuid" in t:
            return uuid.UUID(str(value))
        if "int" in t:
            return int(value)
        if "float" in t or "double" in t or "decimal" in t:
            return float(value)
        if "boolean" in t:
            return parse_bool(value)
        if "timestamp" in t or "date" in t:
            return parse_timestamp(value)
        return value
    except Exception as e:
        raise ValueError(f"Cannot convert '{value}' to type '{cass_type}' → {e}")


def get_table_schema(session, ks, table):
    q = """
    SELECT column_name, type 
    FROM system_schema.columns 
    WHERE keyspace_name=%s AND table_name=%s
    """
    rows = session.execute(q, (ks, table))
    return {r.column_name: getattr(r, "type", "") for r in rows}


# ============================================================
#                  UNFLATTEN HELPERS
# ============================================================
def build_obj_from_flat_row(row):
    obj = {}
    for k, v in row.items():
        if k in ("_rid", "_parent_rid") or v in ("", None):
            continue
        set_nested(obj, k.split("."), v)
    return obj


def collect_child_nodes(child_tables):
    nodes = {}
    cmap = {}
    for path, df in child_tables.items():
        if df.empty:
            continue

        for _, r in df.iterrows():
            d = r.to_dict()
            rid = str(d.get("_rid", ""))
            pr = str(d.get("_parent_rid", ""))
            obj = build_obj_from_flat_row(d)
            nodes[rid] = {"rid": rid, "parent_rid": pr, "path": path, "obj": obj}
            cmap.setdefault(pr, []).append(rid)
    return nodes, cmap


def build_node_json(rid, nodes, cmap, cache):
    if rid in cache:
        return cache[rid]

    node = nodes.get(rid)
    if not node:
        return {}

    base = dict(node["obj"])
    children = cmap.get(rid, [])
    grouped = {}

    for cr in children:
        nd = nodes.get(cr)
        if nd:
            grouped.setdefault(nd["path"], []).append(cr)

    for path, rid_list in grouped.items():
        parts = path.split(".")
        child_objs = [build_node_json(cr, nodes, cmap, cache) for cr in rid_list]

        cur = base
        for i, p in enumerate(parts):
            if i == len(parts) - 1:
                cur[p] = child_objs[0] if len(child_objs) == 1 else child_objs
            else:
                if p not in cur or not isinstance(cur[p], dict):
                    cur[p] = {}
                cur = cur[p]

    cache[rid] = base
    return base


def attach_children_to_parent(obj, parent_rid, nodes, cmap):
    direct = cmap.get(parent_rid, [])
    grouped = {}

    for cr in direct:
        nd = nodes.get(cr)
        if nd:
            grouped.setdefault(nd["path"], []).append(cr)

    cache = {}

    for path, rid_list in grouped.items():
        parts = path.split(".")
        child_objs = [build_node_json(cr, nodes, cmap, cache) for cr in rid_list]

        cur = obj
        for i, p in enumerate(parts):
            if i == len(parts) - 1:
                cur[p] = child_objs[0] if len(child_objs) == 1 else child_objs
            else:
                if p not in cur or not isinstance(cur[p], dict):
                    cur[p] = {}
                cur = cur[p]


# ============================================================
#                DURABLE ACTIVITY FUNCTION
# ============================================================
@app.activity_trigger(input_name="params")
def unflatten_activity(params):
    try:
        # -------------------------------------------------
        # ADLS CONFIG
        # -------------------------------------------------
        adls_acct = params["adls_account_name"]
        adls_key = params["adls_account_key"]
        adls_fs = params["adls_file_system"]

        # -------------------------------------------------
        # CASSANDRA CONFIG
        # -------------------------------------------------
        # contact points
        hosts = params["cassandra_contact_points"]
        if isinstance(hosts, str):
            hosts = [x.strip() for x in hosts.split(",") if x.strip()]

        # NEW: preferred node override
        preferred_node = params.get("cassandra_preferred_node")
        if preferred_node:
            logging.info(f"Using preferred Cassandra node: {preferred_node}")
            hosts = [preferred_node]

        port = int(params.get("cassandra_port", 9042))
        ks = params["cassandra_keyspace"]
        table = params["cassandra_table"]
        truncate_flag = params.get("P_TRUNCATE_SINK_BEFORE_WRITE", False)

        user = params.get("cassandra_username")
        pwd = params.get("cassandra_password")

        # -------------------------------------------------
        # SOURCE DIRECTORY = base_dir + cassandra_table
        # -------------------------------------------------
        base_dir = params["source_directory"].rstrip("/")
        source_dir = f"{base_dir}/{table}"

        svc = get_service_client(adls_acct, adls_key)

        # -------------------------------------------------
        # READ PARENT CSV
        # -------------------------------------------------
        parent_candidates = [
            f"{source_dir}/{table}.csv",
        ]

        parent_df = None
        last_err = None

        for p in parent_candidates:
            try:
                parent_df = read_csv_from_adls(svc, adls_fs, p)
                parent_path = p
                break
            except Exception as e:
                last_err = e

        if parent_df is None:
            raise Exception(f"Parent CSV not found in {source_dir}. Error: {last_err}")

        parent_df.columns = [str(c) for c in parent_df.columns]

        # Auto detect JSON column
        json_col = detect_json_column_from_parent(parent_df)
        logging.info(f"Detected JSON column: {json_col}")

        # -------------------------------------------------
        # READ CHILD FILES
        # -------------------------------------------------
        all_paths = list_paths_in_directory(svc, adls_fs, source_dir)
        child_paths = [p for p in all_paths if p.endswith(".csv") and p != parent_path]

        child_tables = {}
        for p in child_paths:
            rel = p[len(source_dir) + 1:] if p.startswith(source_dir + "/") else p
            parts = rel.split("/")
            base = parts[-1].replace(".csv", "")
            dotted = ".".join(parts[:-1] + [base]) if len(parts) > 1 else base
            dotted = normalize_block_path(dotted)

            df = read_csv_from_adls(svc, adls_fs, p)
            df.columns = [str(c) for c in df.columns]
            child_tables[dotted] = df.fillna("")

        # -------------------------------------------------
        # BUILD CHILD GRAPH
        # -------------------------------------------------
        nodes, cmap = collect_child_nodes(child_tables)

        # -------------------------------------------------
        # CONNECT CASSANDRA USING preferred_node
        # -------------------------------------------------
        if user and pwd:
            auth = PlainTextAuthProvider(user, pwd)
            cluster = Cluster(contact_points=hosts, port=port, auth_provider=auth)
        else:
            cluster = Cluster(contact_points=hosts, port=port)

        session = cluster.connect()

        schema_map = get_table_schema(session, ks, table)

        # -------------------------------------------------
        # TRUNCATE IF REQUIRED
        # -------------------------------------------------
        if truncate_flag:
            logging.info(f"Truncating Cassandra table {ks}.{table}")
            session.execute(f"TRUNCATE {ks}.{table}")

        inserted = 0

        # -------------------------------------------------
        # PROCESS EACH PARENT ROW
        # -------------------------------------------------
        for _, prow in parent_df.iterrows():
            prowd = prow.to_dict()

            parent_rid = prowd.get("_rid")
            if not parent_rid:
                rid_key = f"{json_col}._rid"
                parent_rid = prowd.get(rid_key) or str(uuid.uuid4())

            base_obj = {}
            prefix = f"{json_col}."
            for k, v in prowd.items():
                if k.startswith(prefix) and v not in ("", None):
                    sub = k[len(prefix):]
                    set_nested(base_obj, sub.split("."), v)

            attach_children_to_parent(base_obj, str(parent_rid), nodes, cmap)

            # prune metadata
            def prune(o):
                if isinstance(o, dict):
                    o.pop("_rid", None)
                    o.pop("_parent_rid", None)
                    for v in o.values():
                        prune(v)
                elif isinstance(o, list):
                    for i in o:
                        prune(i)

            prune(base_obj)

            # Build Cassandra row
            cass_row = {}
            for col, ctype in schema_map.items():
                if col == json_col:
                    cass_row[col] = json.dumps(base_obj, ensure_ascii=False)
                elif col in prowd:
                    cass_row[col] = prowd[col]
                elif col in base_obj:
                    cass_row[col] = base_obj[col]
                else:
                    cass_row[col] = None

            for col, ctype in schema_map.items():
                cass_row[col] = cast_value_by_cass_type(cass_row[col], ctype)

            # Insert into Cassandra
            cols = list(cass_row.keys())
            placeholders = ", ".join(["%s"] * len(cols))
            cql = f"INSERT INTO {ks}.{table} ({', '.join(cols)}) VALUES ({placeholders})"

            session.execute(cql, tuple(cass_row[c] for c in cols))

            inserted += 1

        return {
            "status": "success",
            "inserted_rows": inserted,
            "json_column": json_col,
            "used_preferred_node": preferred_node or "No",
            "source_directory_used": source_dir
        }

    except Exception as e:
        logging.exception("ERROR in unflatten_activity")
        return {"status": "error", "message": str(e)}


# ============================================================
#                   ORCHESTRATOR (JSON SAFE)
# ============================================================
@app.orchestration_trigger(context_name="context")
def unflatten_orchestrator(context: df.DurableOrchestrationContext):
    params = context.get_input()
    result = yield context.call_activity("unflatten_activity", params)
    return json.loads(json.dumps(result))


# ============================================================
#                      HTTP STARTER
# ============================================================
@app.route(route="Unflatten_ADLS_To_Cassandra_Durable", methods=["POST"])
@app.durable_client_input(client_name="client")
async def unflatten_http_start(req: func.HttpRequest, client):
    try:
        params = req.get_json()
        instance_id = await client.start_new(
            "unflatten_orchestrator",
            client_input=params
        )
        return client.create_check_status_response(req, instance_id)
    except Exception as e:
        logging.exception("Start error")
        return func.HttpResponse(str(e), status_code=500)
