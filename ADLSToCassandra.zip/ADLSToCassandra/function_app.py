"""
ADLS_to_Cassandra.py
====================
Azure Durable Function — exact reverse of Cassandra_to_ADLS.py.

Reads pipe-delimited CSVs written by Cassandra_to_ADLS, reconstructs
(un-flattens) the original Cassandra rows in batch-wise chunks, and
inserts them back into a Cassandra table.

ADLS layout expected (mirrors Cassandra_to_ADLS output):
---------------------------------------------------------
  <adls_directory>/<table>/
      <table>.csv                           <- relational parent rows (_row_rid key)
      <json_col>/
          <json_col>.csv                    <- JSON scalar fields (linked via _row_rid)
          <array_field>/
              <array_field>.csv             <- depth-0 array rows (_parent_rid = _row_rid)
              <nested_array>/
                  <nested_array>.csv        <- depth-1+ array rows (_parent_rid = _rid)

Key linkage rules (written by Cassandra_to_ADLS):
  - Parent relational CSV    has column: _row_rid
  - JSON scalar CSVs         have column: _row_rid  (links to parent _row_rid)
  - Depth-0 child array CSVs have column: _parent_rid = parent's _row_rid
  - Deeper child array CSVs  have column: _parent_rid = immediate parent's _rid
  - Every child row also has its own: _rid  (used as parent key for next depth)
"""

import ast
import ctypes
import gc
import json
import logging
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from contextlib import contextmanager
from datetime import datetime, date, timezone
from typing import Any, Dict, List, Optional, Set, Tuple

import azure.durable_functions as df
import azure.functions as func
import pandas as pd
from azure.core.exceptions import ClientAuthenticationError, ResourceNotFoundError
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
from azure.storage.filedatalake import DataLakeServiceClient
from cassandra.auth import PlainTextAuthProvider
from cassandra.cluster import Cluster, ExecutionProfile, EXEC_PROFILE_DEFAULT
from cassandra.concurrent import execute_concurrent_with_args
from cassandra.policies import DCAwareRoundRobinPolicy, RoundRobinPolicy
from cassandra.query import BatchStatement, BatchType

# ============================================================================
# CONSTANTS
# ============================================================================

DEFAULT_BATCH_SIZE   = 10_000  # parent rows per processing batch (ADLS read slice)
DEFAULT_CHILD_CHUNK  = 10_000  # rows per chunk when streaming child CSVs
DEFAULT_INSERT_CHUNK = 10      # reconstructed docs to serialise + insert before flushing RAM
DEFAULT_MAX_RETRIES  = 5
DEFAULT_BASE_DELAY   = 0.5     # seconds
DEFAULT_MAX_DELAY    = 60.0    # seconds
DEFAULT_PARALLEL_BATCHES   = 4   # number of batches to process in parallel
DEFAULT_CONCURRENT_INSERTS = 64  # concurrent Cassandra insert statements

PIPE_DELIMITER  = "|"
ESCAPE_CHAR     = "\\"

# Metadata columns written by Cassandra_to_ADLS — stripped before Cassandra insert
SYSTEM_FIELDS: Set[str] = {"_rid", "_parent_rid", "_row_rid"}

# ============================================================================
# AZURE FUNCTIONS APP
# ============================================================================

app = df.DFApp(http_auth_level=func.AuthLevel.ANONYMOUS)


# ============================================================================
# MEMORY MANAGEMENT
# ============================================================================

def force_gc() -> None:
    """Two-pass GC + OS malloc_trim to actually return memory between batches."""
    gc.collect(2)
    gc.collect(2)
    try:
        ctypes.CDLL("libc.so.6").malloc_trim(0)
    except Exception:
        pass


def release_dataframe(df_obj: Optional[pd.DataFrame]) -> None:
    """Null pandas block manager before del so NumPy buffers free immediately."""
    if df_obj is None:
        return
    try:
        df_obj._mgr = None
    except AttributeError:
        try:
            df_obj._data = None
        except AttributeError:
            pass
    del df_obj
    force_gc()


@contextmanager
def memory_managed_batch(label: str = "batch"):
    """Guarantee force_gc() after every batch block, even on exception."""
    try:
        yield
    finally:
        logging.debug(f"[memory] flush after {label}")
        force_gc()


# ============================================================================
# KEY VAULT
# ============================================================================

def get_secret(key_vault_name: str, secret_name: str) -> str:
    kv_uri     = f"https://{key_vault_name}.vault.azure.net"
    credential = DefaultAzureCredential()
    client     = SecretClient(vault_url=kv_uri, credential=credential)
    return client.get_secret(secret_name).value


# ============================================================================
# CASSANDRA
# ============================================================================

def build_cassandra_cluster(
    contact_points: List[str],
    port: int,
    username: str,
    password: str,
    preferred_node: Optional[str] = None,
) -> Cluster:
    auth = PlainTextAuthProvider(username=username, password=password)
    lb   = (
        DCAwareRoundRobinPolicy(local_dc=preferred_node)
        if preferred_node else RoundRobinPolicy()
    )
    return Cluster(
        contact_points=contact_points,
        port=port,
        auth_provider=auth,
        execution_profiles={EXEC_PROFILE_DEFAULT: ExecutionProfile(load_balancing_policy=lb)},
        connect_timeout=30,
        control_connection_timeout=30,
    )


def validate_cassandra_connection(
    contact_points, port, username, password, keyspace, table, preferred_node=None
):
    try:
        cluster = build_cassandra_cluster(contact_points, port, username, password, preferred_node)
        session = cluster.connect(keyspace)
        rows = session.execute(
            "SELECT table_name FROM system_schema.tables WHERE keyspace_name=%s AND table_name=%s",
            (keyspace, table),
        )
        if not rows.one():
            raise ValueError(f"Table '{table}' not found in keyspace '{keyspace}'.")
        del rows
        return cluster, session
    except ValueError:
        raise
    except Exception as e:
        raise ValueError(f"Cassandra connection failed: {str(e)}")


def shutdown_cassandra(cluster, session) -> None:
    for obj in (session, cluster):
        try:
            if obj:
                obj.shutdown()
        except Exception:
            pass
    force_gc()


def get_cassandra_columns(session, keyspace: str, table: str) -> List[str]:
    rows = session.execute(
        "SELECT column_name FROM system_schema.columns WHERE keyspace_name=%s AND table_name=%s",
        (keyspace, table),
    )
    cols = [r.column_name for r in rows]
    del rows
    force_gc()
    return cols


def get_cassandra_column_types(session, keyspace: str, table: str) -> Dict[str, str]:
    """Return {column_name: cql_type} for all columns in the table."""
    rows = session.execute(
        "SELECT column_name, type FROM system_schema.columns WHERE keyspace_name=%s AND table_name=%s",
        (keyspace, table),
    )
    types = {r.column_name: r.type for r in rows}
    del rows
    force_gc()
    return types


def get_cassandra_key_columns(session, keyspace: str, table: str) -> Tuple[List[str], List[str]]:
    """
    Auto-discover partition key and clustering key columns from system_schema.

    Returns:
        (partition_keys, clustering_keys)
        Both lists are ordered by key position.

    This allows the pipeline to automatically apply WHERE-clause filters when
    reading child CSVs, without requiring the user to specify key columns.
    """
    rows = session.execute(
        """
        SELECT column_name, kind, position
        FROM system_schema.columns
        WHERE keyspace_name=%s AND table_name=%s
        """,
        (keyspace, table),
    )
    partition_keys: List[Tuple[int, str]]   = []
    clustering_keys: List[Tuple[int, str]]  = []
    for r in rows:
        if r.kind == "partition_key":
            partition_keys.append((r.position, r.column_name))
        elif r.kind == "clustering":
            clustering_keys.append((r.position, r.column_name))
    partition_keys.sort()
    clustering_keys.sort()
    pk = [c for _, c in partition_keys]
    ck = [c for _, c in clustering_keys]
    logging.info(f"Schema auto-discovered — partition keys: {pk}  clustering keys: {ck}")
    del rows
    force_gc()
    return pk, ck


# Common datetime format strings to try when parsing CSV date strings
_DATETIME_FORMATS = [
    "%Y-%m-%dT%H:%M:%S.%fZ",
    "%Y-%m-%dT%H:%M:%SZ",
    "%Y-%m-%dT%H:%M:%S.%f",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S.%f",
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%d",
]

# ---------------------------------------------------------------------------
# Full CQL → Python type mapping
# ---------------------------------------------------------------------------
# Cassandra DateType  → datetime
_CQL_TIMESTAMP_TYPES = {"timestamp", "date", "time"}
# Cassandra UUIDType  → uuid.UUID
_CQL_UUID_TYPES       = {"uuid", "timeuuid"}
# Cassandra integer types
_CQL_INT_TYPES        = {"int", "tinyint", "smallint", "bigint", "varint", "counter"}
# Cassandra float/decimal types
_CQL_FLOAT_TYPES      = {"float", "double", "decimal"}
# Cassandra boolean
_CQL_BOOL_TYPES       = {"boolean"}
# Cassandra inet
_CQL_INET_TYPES       = {"inet"}


def coerce_value_for_cassandra(value: Any, cql_type: str) -> Any:
    """
    Coerce a CSV string value to the correct Python type for a given CQL column type.

    Handles every primitive Cassandra type so that all-string CSV data can be
    inserted without driver type errors.  Collection types (list<>, set<>, map<>)
    are left for the existing JSON-parse path; only the base element type is
    extracted and used for coercion when the value is a plain scalar string.

    Supported CQL base types and their target Python types:
        timestamp / date / time  → datetime
        uuid / timeuuid          → uuid.UUID
        int / tinyint / smallint
         / bigint / varint
         / counter               → int
        float / double / decimal → float
        boolean                  → bool
        inet                     → str  (validated via ipaddress)
        text / varchar / ascii
         / blob / any other      → str  (no change)
    """
    import uuid as _uuid
    import ipaddress

    if value is None:
        return None

    # Strip collection wrappers: list<uuid> → uuid, frozen<map<text,int>> → map<text,int>
    base_type = cql_type.strip().lower()
    for wrapper in ("frozen<", "list<", "set<", "tuple<"):
        if base_type.startswith(wrapper):
            base_type = base_type[len(wrapper):].rstrip(">").strip()
            break
    # For map<k,v> take the value type (values are what we usually care about)
    if base_type.startswith("map<"):
        inner = base_type[4:].rstrip(">")
        parts = inner.split(",", 1)
        base_type = parts[1].strip() if len(parts) == 2 else parts[0].strip()

    # Already the right type — nothing to do
    if not isinstance(value, str):
        return value

    v = value.strip()
    if v == "":
        return None

    # ── timestamp / date / time ──────────────────────────────────────────────
    if base_type in _CQL_TIMESTAMP_TYPES:
        for fmt in _DATETIME_FORMATS:
            try:
                return datetime.strptime(v, fmt)
            except ValueError:
                continue
        try:
            return pd.Timestamp(v).to_pydatetime()
        except Exception:
            pass
        logging.warning(f"Cannot parse datetime '{v}' for CQL type '{cql_type}' — passing as-is.")
        return value

    # ── uuid / timeuuid ──────────────────────────────────────────────────────
    if base_type in _CQL_UUID_TYPES:
        try:
            return _uuid.UUID(v)
        except (ValueError, AttributeError):
            logging.warning(f"Cannot parse UUID '{v}' for CQL type '{cql_type}' — passing as-is.")
            return value

    # ── integer types ────────────────────────────────────────────────────────
    if base_type in _CQL_INT_TYPES:
        try:
            # Handle float-formatted integers stored in CSV e.g. "12345.0"
            return int(float(v)) if "." in v else int(v)
        except (ValueError, TypeError):
            logging.warning(f"Cannot parse int '{v}' for CQL type '{cql_type}' — passing as-is.")
            return value

    # ── float / double / decimal ─────────────────────────────────────────────
    if base_type in _CQL_FLOAT_TYPES:
        try:
            return float(v)
        except (ValueError, TypeError):
            logging.warning(f"Cannot parse float '{v}' for CQL type '{cql_type}' — passing as-is.")
            return value

    # ── boolean ──────────────────────────────────────────────────────────────
    if base_type in _CQL_BOOL_TYPES:
        lower_v = v.lower()
        if lower_v in ("true", "1", "yes"):
            return True
        if lower_v in ("false", "0", "no"):
            return False
        logging.warning(f"Cannot parse boolean '{v}' for CQL type '{cql_type}' — passing as-is.")
        return value

    # ── inet ─────────────────────────────────────────────────────────────────
    if base_type in _CQL_INET_TYPES:
        try:
            ipaddress.ip_address(v)   # validate; driver accepts the string itself
        except ValueError:
            logging.warning(f"Invalid inet address '{v}' — passing as-is.")
        return v

    # ── text / varchar / ascii / blob / anything else ────────────────────────
    return value


# ============================================================================
# ADLS
# ============================================================================

def validate_adls_connection(adls_account_name: str, adls_file_system: str) -> DataLakeServiceClient:
    try:
        credential     = DefaultAzureCredential()
        service_client = DataLakeServiceClient(
            account_url=f"https://{adls_account_name}.dfs.core.windows.net",
            credential=credential,
        )
        fs_client = service_client.get_file_system_client(adls_file_system)
        list(fs_client.get_paths(path="", max_results=1))
        return service_client
    except ClientAuthenticationError:
        raise ValueError("ADLS authentication failed. Check managed identity permissions.")
    except ResourceNotFoundError:
        raise ValueError(f"ADLS filesystem '{adls_file_system}' does not exist.")
    except Exception as e:
        raise ValueError(f"ADLS connection failed: {str(e)}")


def get_csv_row_count(service_client, file_system, full_path, chunk_size=50_000) -> int:
    """Count rows in a CSV by streaming in chunks — never loads full file into RAM."""
    try:
        fs_client   = service_client.get_file_system_client(file_system)
        download    = fs_client.get_file_client(full_path).download_file()
        total = 0
        for chunk in pd.read_csv(
            download, sep=PIPE_DELIMITER, chunksize=chunk_size,
            iterator=True, keep_default_na=False, escapechar=ESCAPE_CHAR,
        ):
            total += len(chunk)
            del chunk
        return total
    except Exception as e:
        logging.error(f"Error counting rows in '{full_path}': {str(e)}")
        raise


def read_csv_from_adls_batched(
    service_client, file_system, full_path, skip_rows=0, nrows=None
) -> pd.DataFrame:
    """
    Read a skip_rows/nrows slice of a CSV from ADLS.
    All columns are read as strings; empty strings are normalised to None.
    """
    try:
        fs_client   = service_client.get_file_system_client(file_system)
        download    = fs_client.get_file_client(full_path).download_file()

        read_params: Dict[str, Any] = {
            "sep": PIPE_DELIMITER, "keep_default_na": False,
            "escapechar": ESCAPE_CHAR, "dtype": str,
        }
        if skip_rows > 0:
            read_params["skiprows"] = range(1, skip_rows + 1)
        if nrows:
            read_params["nrows"] = nrows

        df_out = pd.read_csv(download, **read_params)
        df_out = df_out.where(df_out != "", other=None)
        return df_out
    except Exception as e:
        logging.error(f"Error reading CSV '{full_path}' (skip={skip_rows}, nrows={nrows}): {e}")
        raise


def discover_all_csv_paths(service_client, file_system, export_dir) -> List[str]:
    """Recursively list all .csv paths under export_dir."""
    fs_client = service_client.get_file_system_client(file_system)
    paths: List[str] = []
    try:
        for item in fs_client.get_paths(path=export_dir, recursive=True):
            if not item.is_directory and item.name.endswith(".csv"):
                paths.append(item.name)
    except Exception as e:
        logging.warning(f"Could not list paths under '{export_dir}': {e}")
    return paths


# ============================================================================
# CSV PATH CLASSIFICATION
#
# Cassandra_to_ADLS produces this layout:
#
#   <export_dir>/
#       <table>.csv                         <- relational parent
#       <jcol>/
#           <jcol>.csv                      <- JSON scalar CSV  (2 parts, stem==dir)
#           <arr>/
#               <arr>.csv                   <- depth-0 array  (3 parts total)
#               <nested>/
#                   <nested>.csv            <- depth-1 array   (4 parts total)
#
# Rules:
#   - Scalar CSV:  rel_parts == [jcol, jcol.csv]  → len==2, stem==parts[0]
#   - Array CSV:   rel_parts == [jcol, arr, arr.csv]  (depth 0)
#                  rel_parts == [jcol, arr, nested, nested.csv]  (depth 1)
#
#   arr_name = dotted join of parts[1:-1]  (array dirs BELOW jcol, NO jcol prefix)
#   depth    = len(parts[1:-1]) - 1        (0-based: one array dir = depth 0)
#   jcol     = parts[0]                    (stored per entry so we know which JSON column)
# ============================================================================

def get_json_col_scalar_paths(csv_paths, export_dir, table) -> Dict[str, str]:
    """
    Return {jcol_name: full_adls_path} for each JSON column scalar CSV.

    Signature: exactly 2 path parts below export_dir AND filename stem == directory name.
    e.g.  profile/profile.csv  -> jcol="profile"
    """
    parent_csv  = f"{export_dir}/{table}.csv"
    scalar_map: Dict[str, str] = {}
    for full_path in csv_paths:
        if full_path == parent_csv:
            continue
        rel   = full_path[len(export_dir):].lstrip("/")
        parts = [p for p in rel.split("/") if p]
        if len(parts) == 2 and parts[-1].rsplit(".", 1)[0] == parts[0]:
            scalar_map[parts[0]] = full_path
    return scalar_map


def organize_csv_paths_by_depth(csv_paths, export_dir, table) -> Dict[int, List[Dict]]:
    """
    Classify every array CSV by its nesting depth and which JSON column it belongs to.

    Two kinds of array CSVs exist:
    A) Top-level arrays — columns that are native Cassandra columns storing JSON arrays.
       These sit directly under export_dir with NO jcol parent directory:
           orders/orders.csv            -> depth 0, jcol=None, arr_name="orders"
           orders/items/items.csv       -> depth 1, jcol=None, arr_name="orders.items"

    B) JSON-column arrays — arrays that live *inside* a JSON text column.
       These sit under a jcol subdirectory:
           profile/orders/orders.csv    -> depth 0, jcol="profile", arr_name="orders"
           profile/orders/items/items.csv -> depth 1, jcol="profile", arr_name="orders.items"

    Detection rule:
        rel_parts = path below export_dir split on "/"
        If len==2 AND stem==parts[0]:  scalar JSON col CSV  → skip (handled separately)
        If len==2 AND stem!=parts[0]:  IMPOSSIBLE by naming convention
        If len>=2:
            Try to decide if parts[0] is a jcol or a top-level array dir.
            A path is a TOP-LEVEL array if:
              - it has exactly (depth+2) parts where the filename stem matches
                the last directory name  (e.g. [orders, orders.csv] or
                [orders, items, items.csv])
              - AND parts[0] does NOT appear as a jcol scalar CSV key
            Otherwise treat parts[0] as a jcol.

    In practice we make two passes:
        Pass 1: collect known jcol names (from scalar CSVs).
        Pass 2: classify each remaining CSV.

    Returns:
        {depth: [{"full_path", "arr_name", "jcol", "depth"}]}
        jcol is None for top-level array CSVs.
    """
    parent_csv = f"{export_dir}/{table}.csv"

    # Pass 1: collect known jcol names from scalar CSV paths
    known_jcols: Set[str] = set()
    for full_path in csv_paths:
        if full_path == parent_csv:
            continue
        rel   = full_path[len(export_dir):].lstrip("/")
        parts = [p for p in rel.split("/") if p]
        if len(parts) == 2 and parts[-1].rsplit(".", 1)[0] == parts[0]:
            known_jcols.add(parts[0])

    result: Dict[int, List[Dict]] = {}

    # Pass 2: classify array CSVs
    for full_path in sorted(csv_paths):
        if full_path == parent_csv:
            continue
        rel   = full_path[len(export_dir):].lstrip("/")
        parts = [p for p in rel.split("/") if p]
        if not parts:
            continue

        filename_stem = parts[-1].rsplit(".", 1)[0]

        # Skip scalar JSON-column CSVs (handled separately)
        if len(parts) == 2 and filename_stem == parts[0]:
            continue

        # Determine if this is a top-level array or a jcol-nested array.
        # Top-level: parts[0] is NOT a known jcol scalar column.
        if parts[0] not in known_jcols:
            # Top-level array:  all dirs up to (but not including) filename are arr_dirs
            # e.g. [orders, orders.csv]           -> arr_dirs=["orders"], depth=0
            # e.g. [orders, items, items.csv]     -> arr_dirs=["orders","items"], depth=1
            arr_dirs = parts[:-1]               # all directory components
            arr_name = ".".join(arr_dirs)
            depth    = len(arr_dirs) - 1        # 0-based
            jcol     = None
        else:
            # jcol-nested array: parts[0] = jcol.
            # Cassandra_to_ADLS repeats the jcol name as an immediate subdirectory,
            # so the actual array dirs start at parts[2], not parts[1].
            # e.g. customer_summary/customer_summary/orders/orders.csv
            #      parts = [customer_summary, customer_summary, orders, orders.csv]
            #      jcol="customer_summary", arr_dirs=["orders"], arr_name="orders", depth=0
            jcol = parts[0]
            # Strip the repeated jcol dir if present as parts[1]
            if len(parts) > 2 and parts[1] == jcol:
                arr_dirs = parts[2:-1]          # skip repeated jcol subdir
            else:
                arr_dirs = parts[1:-1]          # fallback: no repeated subdir
            arr_name = ".".join(arr_dirs)
            depth    = len(arr_dirs) - 1        # 0-based

        if depth < 0 or not arr_name:
            continue

        result.setdefault(depth, []).append({
            "full_path": full_path,
            "arr_name":  arr_name,
            "jcol":      jcol,
            "depth":     depth,
        })

    return result


# ============================================================================
# UNFLATTEN HELPERS
# ============================================================================

def parse_json_string(value: str) -> Any:
    """Try JSON then ast.literal_eval; return original string on failure."""
    v = value.strip()
    if (v.startswith("[") and v.endswith("]")) or (v.startswith("{") and v.endswith("}")):
        try:
            return json.loads(v)
        except Exception:
            try:
                return ast.literal_eval(v)
            except Exception:
                pass
    return value


def unflatten_dict(flat: Dict[str, Any], sep: str = ".") -> Dict:
    """
    Convert flat dotted-key dict → nested dict.

    "address.city" = "NY", "address.zip" = "10001"
    → {"address": {"city": "NY", "zip": "10001"}}

    String values run through parse_json_string so serialised arrays/objects
    stored in CSV cells are restored as Python objects.
    """
    result: Dict = {}
    for key, value in flat.items():
        if isinstance(value, str):
            value = parse_json_string(value)
        parts   = key.split(sep)
        current = result
        for i, part in enumerate(parts):
            if i == len(parts) - 1:
                current[part] = value
            else:
                if part not in current or not isinstance(current[part], dict):
                    current[part] = {}
                current = current[part]
    return result


def strip_system_fields(obj: Any) -> Any:
    """Recursively remove _rid, _parent_rid, _row_rid, _has_array_* from a doc."""
    if isinstance(obj, dict):
        return {
            k: strip_system_fields(v)
            for k, v in obj.items()
            if k not in SYSTEM_FIELDS and not k.startswith("_has_array_")
        }
    if isinstance(obj, list):
        return [strip_system_fields(v) for v in obj]
    return obj


def cassandra_safe(obj: Any) -> Any:
    """Convert numpy/pandas scalars to plain Python types for Cassandra."""
    if isinstance(obj, dict):
        return {str(k): cassandra_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [cassandra_safe(v) for v in obj]
    try:
        import numpy as np
        if isinstance(obj, (np.integer,)):       return int(obj)
        if isinstance(obj, (np.floating,)):      return float(obj)
        if isinstance(obj, (np.bool_,)):         return bool(obj)
    except ImportError:
        pass
    try:
        if isinstance(obj, float) and pd.isna(obj): return None
        if obj is pd.NaT:                           return None
    except Exception:
        pass
    return obj


# ============================================================================
# PREPARE BATCH PARENTS
# ============================================================================

def prepare_batch_parents(parent_df: pd.DataFrame) -> List[Dict]:
    """
    Convert relational parent CSV slice → list of partially-nested dicts.

    - Regular (non-array-marker) fields are un-flattened via unflatten_dict.
    - _has_array_* markers are preserved at the TOP LEVEL of the dict so
      _initialize_arrays_from_markers can find them.
    - _row_rid is preserved (used as the link key for scalar and depth-0 child CSVs).
    - _rid is preserved if present (unlikely in relational parent but harmless).
    """
    parents: List[Dict] = []
    for _, row in parent_df.iterrows():
        flat = {k: v for k, v in row.items() if v is not None and v == v}  # drop NA

        has_array_fields = {k: v for k, v in flat.items() if k.startswith("_has_array_")}
        regular_fields   = {
            k: v for k, v in flat.items()
            if not k.startswith("_has_array_") and k != "_parent_rid"
        }

        nested = unflatten_dict(regular_fields)
        # Re-attach markers at top level (unflatten_dict would try to nest them
        # via dots which doesn't apply to _has_array_ keys)
        nested.update(has_array_fields)
        parents.append(nested)

    return parents


# ============================================================================
# CHILD OBJECT BUILDER
# ============================================================================

def _build_child_object(row: pd.Series) -> Dict:
    """
    Build a nested child object from a CSV row.

    - Preserves _rid and _parent_rid as metadata.
    - Preserves _has_array_* markers at top level.
    - Un-flattens all other fields via unflatten_dict.
    """
    rid        = str(row.get("_rid",        "") or "") if pd.notna(row.get("_rid"))        else None
    parent_rid = str(row.get("_parent_rid", "") or "") if pd.notna(row.get("_parent_rid")) else None

    regular: Dict = {}
    has_array: Dict = {}

    for k, v in row.items():
        if k in ("_rid", "_parent_rid"):
            continue
        if not pd.notna(v) or v == "":
            continue
        if k.startswith("_has_array_"):
            has_array[k] = v
        else:
            regular[k] = v

    nested = unflatten_dict(regular)
    nested.update(has_array)
    nested["_rid"]        = rid
    nested["_parent_rid"] = parent_rid
    return nested


# ============================================================================
# STREAM CHILD CSV
# ============================================================================

def process_child_csv_streaming(
    service_client,
    file_system: str,
    full_path: str,
    parent_rids: Set[str],
    arr_name: str,
    all_objects_by_rid: Dict,
    child_objects_by_table: Dict,
) -> Tuple[int, Set[str]]:
    """
    Stream a child array CSV in chunks, filter by parent_rids, build child objects.

    Each chunk is filtered and released immediately — only matching rows persist.

    Args:
        parent_rids:  Set of _parent_rid values to filter on.
                      For depth-0 arrays this is the set of _row_rid from parent CSV.
                      For deeper arrays this is the set of _rid from the previous depth.
        arr_name:     Dotted array name WITHOUT jcol prefix (e.g. "orders", "orders.items").
        all_objects_by_rid:     Global _rid → object dict (updated with child _rid entries).
        child_objects_by_table: Accumulator {arr_name: [child_dicts]}.

    Returns:
        (row_count, set_of_child_rids)
    """
    try:
        fs_client   = service_client.get_file_system_client(file_system)
        download    = fs_client.get_file_client(full_path).download_file()

        child_rids: Set[str] = set()
        row_count = 0
        child_objects_by_table.setdefault(arr_name, [])

        chunk_iter = pd.read_csv(
            download,
            sep=PIPE_DELIMITER, chunksize=DEFAULT_CHILD_CHUNK,
            iterator=True, keep_default_na=False, escapechar=ESCAPE_CHAR, dtype=str,
        )

        for chunk in chunk_iter:
            if "_parent_rid" not in chunk.columns:
                del chunk
                continue

            chunk["_parent_rid"] = chunk["_parent_rid"].fillna("").astype(str)
            filtered = chunk[chunk["_parent_rid"].isin(parent_rids)].copy()
            del chunk

            if filtered.empty:
                release_dataframe(filtered)
                continue

            if "_rid" in filtered.columns:
                filtered["_rid"] = filtered["_rid"].fillna("").astype(str)

            for _, row in filtered.iterrows():
                obj = _build_child_object(row)
                child_objects_by_table[arr_name].append(obj)
                if obj.get("_rid"):
                    child_rids.add(obj["_rid"])
                    all_objects_by_rid[obj["_rid"]] = obj
                row_count += 1

            release_dataframe(filtered)

        logging.info(f"  [{arr_name}] {row_count} rows, {len(child_rids)} child RIDs")
        return row_count, child_rids

    except Exception as e:
        logging.error(f"Error streaming child CSV '{full_path}': {e}")
        raise


# ============================================================================
# ARRAY MARKER HANDLING
# ============================================================================

def _record_array_markers(all_objects_by_rid: Dict, arrays_with_markers: Dict,
                          row_rid_to_parent: Optional[Dict] = None) -> None:
    """
    Build reverse index: array_name -> set of RIDs that carry _has_array_<n>.

    Root parent docs must be indexed by BOTH _rid (if present) AND _row_rid
    because depth-0 children link via _parent_rid = _row_rid, not _rid.
    """
    for rid, obj in all_objects_by_rid.items():
        for key in list(obj.keys()):
            if key.startswith("_has_array_"):
                arr_name = key[len("_has_array_"):]
                arrays_with_markers.setdefault(arr_name, set()).add(rid)

    # Also index root parents by their _row_rid
    if row_rid_to_parent:
        for row_rid, obj in row_rid_to_parent.items():
            for key in list(obj.keys()):
                if key.startswith("_has_array_"):
                    arr_name = key[len("_has_array_"):]
                    arrays_with_markers.setdefault(arr_name, set()).add(row_rid)


def _initialize_arrays_from_markers(all_objects_by_rid: Dict) -> None:
    """
    For every _has_array_<name> marker: create an empty list at the nested
    path <name> inside the object, then remove the marker key.
    """
    for _rid, obj in all_objects_by_rid.items():
        for marker in [k for k in list(obj.keys()) if k.startswith("_has_array_")]:
            arr_name   = marker[len("_has_array_"):]
            path_parts = arr_name.split(".")
            target     = obj
            ok         = True
            for part in path_parts[:-1]:
                if part not in target:
                    target[part] = {}
                elif not isinstance(target[part], dict):
                    ok = False; break
                target = target[part]
            if ok:
                final = path_parts[-1]
                if final not in target:
                    target[final] = []
            if marker in obj:
                del obj[marker]


def _determine_filter_rids(
    arr_name: str,
    current_depth: int,
    row_rid_set: Set[str],
    rids_by_depth: Dict[int, Set[str]],
    all_objects_by_rid: Dict,
) -> Set[str]:
    """
    Choose which _parent_rid values to use when filtering a child CSV.

    FIX vs previous version:
    - row_rid_set (the _row_rid values from parent CSV) is used at depth 0
      because depth-0 child CSVs have _parent_rid = parent _row_rid.
    - rids_by_depth[d] (collected _rid values) is used for depth > 0.
    - _has_array_* markers are checked with arr_name (NO jcol prefix).

    Args:
        arr_name:       Array name WITHOUT jcol prefix (e.g. "orders").
        current_depth:  0-based depth.
        row_rid_set:    Set of _row_rid values from parent relational CSV.
        rids_by_depth:  {depth: set_of_child_rids_at_that_depth}.
        all_objects_by_rid: Global RID → object lookup.
    """
    arr_parts        = arr_name.split(".")
    possible_markers = [".".join(arr_parts[i:]) for i in range(len(arr_parts))]

    # The correct parent ID set for this depth
    if current_depth == 0:
        parent_id_set = row_rid_set
    else:
        parent_id_set = set()
        for d in range(current_depth, -1, -1):
            if d in rids_by_depth and rids_by_depth[d]:
                parent_id_set = rids_by_depth[d]
                break

    # Try to narrow using _has_array_* markers
    for marker_suffix in possible_markers:
        marker_key       = f"_has_array_{marker_suffix}"
        rids_with_marker = {
            rid for rid, obj in all_objects_by_rid.items() if marker_key in obj
        }
        if rids_with_marker:
            valid = rids_with_marker & parent_id_set
            if valid:
                return valid

    # Fallback: return full parent ID set for this depth
    return parent_id_set


def _assign_children_to_parents(
    child_objects_by_table: Dict,
    all_objects_by_rid: Dict,
    row_rid_to_parent: Dict,
    arrays_with_markers: Dict,
) -> None:
    """
    Assign child objects into the correct nested array of their parent document.

    FIX vs previous version:
    - row_rid_to_parent (keyed by _row_rid) is the lookup for depth-0 children
      because depth-0 children have _parent_rid = parent _row_rid.
    - all_objects_by_rid covers deeper children (keyed by _rid).
    - arr_name has NO jcol prefix, so path navigation is correct.
    """
    sorted_tables = sorted(child_objects_by_table.items(), key=lambda x: x[0].count("."))

    for arr_name, objects in sorted_tables:
        if not objects:
            continue

        grouped: Dict[str, List[Dict]] = defaultdict(list)
        for obj in objects:
            p_rid = str(obj.get("_parent_rid", "") or "")
            if p_rid and p_rid != "None":
                grouped[p_rid].append(obj)

        for p_rid, children in grouped.items():
            # Look up the parent object — could be a root parent or an intermediate child
            parent_obj = all_objects_by_rid.get(p_rid) or row_rid_to_parent.get(p_rid)
            if parent_obj is None:
                continue

            clean_children = _clean_child_objects(children, all_objects_by_rid)
            _add_children_to_array(parent_obj, arr_name, clean_children, p_rid, arrays_with_markers)


def _clean_child_objects(children: List[Dict], all_objects_by_rid: Dict,
                         preserve_markers: bool = True) -> List[Dict]:
    """
    Strip _rid/_parent_rid from children; update the all_objects_by_rid lookup.

    _has_array_* markers are intentionally KEPT on the cleaned dict so that
    deeper child arrays can still be assigned into the correct nested list.
    They are removed later by _clean_documents after all children are placed.
    """
    clean_list: List[Dict] = []
    for child in children:
        child_rid = str(child.get("_rid", "") or "")
        # Keep _has_array_* markers; only strip navigation metadata
        clean = {
            k: v for k, v in child.items()
            if k not in ("_rid", "_parent_rid")
        }
        clean_list.append(clean)
        if child_rid and child_rid in all_objects_by_rid:
            all_objects_by_rid[child_rid] = clean
    return clean_list


def _add_children_to_array(
    parent_obj: Dict,
    arr_name: str,
    clean_children: List[Dict],
    parent_rid: str,
    arrays_with_markers: Dict,
) -> None:
    """
    Insert clean_children into the correct nested list inside parent_obj.

    arr_name has NO jcol prefix.

    FIX vs previous version:
    - For depth-0 arrays (e.g. "orders") the marker "_has_array_orders" is on
      the root parent.  path_segments = ["orders"], so target = parent_obj
      directly — no intermediate dict navigation needed.
    - For nested arrays (e.g. "orders.items") the marker "_has_array_orders.items"
      or "_has_array_items" will be on the intermediate "orders" child object,
      not on the root parent.  Navigation walks parent_obj["orders"][i] for each
      order row to find the right target.
    - Fallback places children at the leaf key of arr_name.
    """
    # Determine the correct placement path via marker lookup
    has_marker      = False
    actual_arr_name = None

    if parent_rid in arrays_with_markers.get(arr_name, set()):
        has_marker      = True
        actual_arr_name = arr_name
    else:
        for marker, rids in arrays_with_markers.items():
            if parent_rid in rids and (arr_name.endswith(marker) or arr_name == marker):
                has_marker      = True
                actual_arr_name = marker
                break

    if has_marker and actual_arr_name:
        path_segments = actual_arr_name.split(".")
        target        = parent_obj
        for part in path_segments[:-1]:
            if part not in target:
                target[part] = {}
            elif not isinstance(target[part], dict):
                return
            target = target[part]
        final_key = path_segments[-1]
        if final_key not in target:
            target[final_key] = []
        if isinstance(target[final_key], list):
            target[final_key].extend(clean_children)
        else:
            target[final_key] = clean_children
    else:
        # Fallback: use leaf segment of arr_name
        path_segments = arr_name.split(".")
        final_key     = path_segments[-1]
        # Navigate intermediate path if needed
        target = parent_obj
        for part in path_segments[:-1]:
            target = target.setdefault(part, {})
        if final_key not in target:
            target[final_key] = []
        if isinstance(target[final_key], list):
            target[final_key].extend(clean_children)
        else:
            target[final_key] = clean_children


def _clean_documents(documents: List[Dict]) -> None:
    """
    Recursively strip all metadata (_rid, _parent_rid, _row_rid, _has_array_*)
    from documents and all nested child objects in place.
    """
    def _clean_recursive(obj: Any) -> Any:
        if isinstance(obj, dict):
            return {
                k: _clean_recursive(v) for k, v in obj.items()
                if k not in SYSTEM_FIELDS and not k.startswith("_has_array_")
            }
        if isinstance(obj, list):
            return [_clean_recursive(item) for item in obj]
        return obj

    for doc in documents:
        # Recursively clean all non-metadata values
        for key in list(doc.keys()):
            if key not in SYSTEM_FIELDS and not key.startswith("_has_array_"):
                doc[key] = _clean_recursive(doc[key])
        # Remove all metadata keys from the root doc
        for key in list(doc.keys()):
            if key in SYSTEM_FIELDS or key.startswith("_has_array_"):
                del doc[key]


# ============================================================================
# JSON COLUMN SCALAR CSV
# ============================================================================

def process_json_col_scalar_csv(
    service_client,
    file_system: str,
    scalar_path: str,
    jcol: str,
    parent_row_rids: Set[str],
    row_rid_to_parent: Dict,
) -> None:
    """
    Read the flattened-scalar CSV for one JSON column, filter by _row_rid,
    un-flatten the fields, and merge them back into the parent document.

    The scalar CSV was produced by Cassandra_to_ADLS from the JSON text column.
    Each row corresponds to one Cassandra row and links via _row_rid.
    Un-flattening dotted keys restores the original nested JSON structure.
    The result is stored as parent_doc[jcol] = nested_dict so that the
    main loop can later json.dumps() it back to a string for Cassandra.

    Args:
        parent_row_rids:   Set of _row_rid values in the current batch.
        row_rid_to_parent: _row_rid → parent_doc lookup (mutated in place).
    """
    try:
        fs_client   = service_client.get_file_system_client(file_system)
        download    = fs_client.get_file_client(scalar_path).download_file()

        chunk_iter = pd.read_csv(
            download, sep=PIPE_DELIMITER, chunksize=DEFAULT_CHILD_CHUNK,
            iterator=True, keep_default_na=False, escapechar=ESCAPE_CHAR, dtype=str,
        )

        for chunk in chunk_iter:
            if "_row_rid" not in chunk.columns:
                del chunk
                continue

            chunk["_row_rid"] = chunk["_row_rid"].fillna("").astype(str)
            filtered = chunk[chunk["_row_rid"].isin(parent_row_rids)].copy()
            del chunk

            if filtered.empty:
                release_dataframe(filtered)
                continue

            for _, row in filtered.iterrows():
                row_rid = str(row.get("_row_rid", "") or "")
                parent  = row_rid_to_parent.get(row_rid)
                if parent is None:
                    continue

                # Un-flatten all non-metadata fields into a nested dict
                scalar_flat = {
                    k: v for k, v in row.items()
                    if k not in SYSTEM_FIELDS
                    and not k.startswith("_has_array_")
                    and pd.notna(v) and v != ""
                }
                if not scalar_flat:
                    continue

                nested_scalars = unflatten_dict(scalar_flat)

                # Merge into parent[jcol]
                existing = parent.get(jcol)
                if isinstance(existing, dict):
                    existing.update(nested_scalars)
                else:
                    parent[jcol] = nested_scalars

            release_dataframe(filtered)

    except Exception as e:
        logging.error(f"Error in scalar CSV '{scalar_path}' for column '{jcol}': {e}")
        raise


# ============================================================================
# CORE BATCH PROCESSING
# ============================================================================

def process_batch(
    batch_parents: List[Dict],
    service_client,
    file_system: str,
    export_dir: str,
    table: str,
    json_col_scalar_paths: Dict[str, str],
    csv_info_by_depth: Dict[int, List[Dict]],
) -> Tuple[List[Dict], int]:
    """
    Reconstruct fully nested documents for one batch of parent rows.

    Steps
    -----
    1.  Build lookups:
          row_rid_to_parent   (_row_rid → parent doc)
          all_objects_by_rid  (_rid     → any object at any depth)
          parent_rids         set of _row_rid values (used for depth-0 array filter)
    2.  For each JSON column scalar CSV: stream + merge scalars via _row_rid.
    3.  Process child array CSVs depth-by-depth:
          depth 0: filter_rids = parent _row_rid values
          depth d: filter_rids = _rid values collected from depth d-1
    4.  Record _has_array_* markers → init empty arrays → assign children.
    5.  Clean documents (strip all metadata).
    6.  Release all intermediate dicts + force GC.

    Key FIXes:
    - row_rid_set (not rid_set) is used as filter for depth-0 children.
    - arr_name in csv_info_by_depth has NO jcol prefix (fixed in organize_csv_paths_by_depth).
    - _assign_children_to_parents uses row_rid_to_parent as fallback lookup.
    """
    # ── 1. Build lookups ─────────────────────────────────────────────────────
    row_rid_to_parent: Dict[str, Dict] = {}
    rid_to_parent:     Dict[str, Dict] = {}

    for parent in batch_parents:
        rrid = str(parent.get("_row_rid", "") or "")
        rid  = str(parent.get("_rid", "") or "")
        if rrid:
            row_rid_to_parent[rrid] = parent
        if rid:
            rid_to_parent[rid] = parent

    # all_objects_by_rid starts with rid-keyed parents; grows as child _rid values are added
    all_objects_by_rid: Dict[str, Dict] = dict(rid_to_parent)
    row_rid_set        = set(row_rid_to_parent.keys())   # depth-0 filter key
    total_child_rows   = 0

    # ── 2. JSON column scalar CSVs ───────────────────────────────────────────
    for jcol, scalar_path in json_col_scalar_paths.items():
        try:
            process_json_col_scalar_csv(
                service_client    = service_client,
                file_system       = file_system,
                scalar_path       = scalar_path,
                jcol              = jcol,
                parent_row_rids   = row_rid_set,
                row_rid_to_parent = row_rid_to_parent,
            )
        except Exception as e:
            logging.error(f"Scalar CSV error for '{jcol}': {e} — continuing.")

    # ── 3. Child array CSVs depth-by-depth ───────────────────────────────────
    # rids_by_depth[d] = set of _rid values found at depth d
    # depth-0 children have _parent_rid = row_rid, so we pass row_rid_set separately
    rids_by_depth: Dict[int, Set[str]] = {}
    child_objects_by_table: Dict[str, List[Dict]] = {}
    arrays_with_markers:    Dict[str, Set[str]]   = {}
    max_depth = max(csv_info_by_depth.keys()) if csv_info_by_depth else -1

    for depth in range(max_depth + 1):
        if depth not in csv_info_by_depth:
            continue
        rids_by_depth.setdefault(depth + 1, set())

        for csv_info in csv_info_by_depth[depth]:
            filter_rids = _determine_filter_rids(
                arr_name           = csv_info["arr_name"],
                current_depth      = depth,
                row_rid_set        = row_rid_set,
                rids_by_depth      = rids_by_depth,
                all_objects_by_rid = all_objects_by_rid,
            )
            if not filter_rids:
                logging.debug(f"  No filter RIDs for '{csv_info['arr_name']}' depth={depth}")
                continue

            try:
                child_count, child_rids = process_child_csv_streaming(
                    service_client         = service_client,
                    file_system            = file_system,
                    full_path              = csv_info["full_path"],
                    parent_rids            = filter_rids,
                    arr_name               = csv_info["arr_name"],
                    all_objects_by_rid     = all_objects_by_rid,
                    child_objects_by_table = child_objects_by_table,
                )
                total_child_rows          += child_count
                rids_by_depth[depth + 1].update(child_rids)
            except Exception as e:
                logging.error(f"Error processing '{csv_info['full_path']}': {e}")
                continue

    # ── 4. Assign children into parents ──────────────────────────────────────
    # Record markers from all objects (intermediate children) AND root parents
    # (keyed by _row_rid, which is what depth-0 _parent_rid values match).
    _record_array_markers(all_objects_by_rid, arrays_with_markers,
                          row_rid_to_parent=row_rid_to_parent)

    # Initialize empty arrays on all objects that carry _has_array_* markers.
    # This must happen on BOTH all_objects_by_rid entries AND root parents.
    _initialize_arrays_from_markers(all_objects_by_rid)
    _initialize_arrays_from_markers(row_rid_to_parent)  # root parents keyed by _row_rid

    _assign_children_to_parents(
        child_objects_by_table,
        all_objects_by_rid,
        row_rid_to_parent,
        arrays_with_markers,
    )

    # ── 5. Clean metadata from all documents ─────────────────────────────────
    _clean_documents(batch_parents)
    documents = [cassandra_safe(strip_system_fields(doc)) for doc in batch_parents]

    # ── 6. Release intermediates ──────────────────────────────────────────────
    del row_rid_to_parent, rid_to_parent, all_objects_by_rid
    del child_objects_by_table, arrays_with_markers, rids_by_depth
    force_gc()

    return documents, total_child_rows


# ============================================================================
# RETRY STRATEGY
# ============================================================================

class CassandraRetryStrategy:
    def __init__(self, max_retries=DEFAULT_MAX_RETRIES, base_delay=DEFAULT_BASE_DELAY, max_delay=DEFAULT_MAX_DELAY):
        self.max_retries = max_retries
        self.base_delay  = base_delay
        self.max_delay   = max_delay
        self.retry_counts: Dict[str, int] = {}

    def execute_with_retry(self, operation, name="op"):
        import random
        for attempt in range(self.max_retries + 1):
            try:
                return operation()
            except Exception as e:
                etype = self._classify(str(e))
                self.retry_counts[etype] = self.retry_counts.get(etype, 0) + 1
                if attempt < self.max_retries:
                    wait = min(self.base_delay * (2 ** attempt), self.max_delay)
                    wait += random.uniform(0, 0.1 * wait)
                    logging.warning(f"[retry] {name} ({etype}) attempt {attempt+1}/{self.max_retries+1} wait={wait:.2f}s")
                    time.sleep(wait)
                else:
                    logging.error(f"[retry] {name} failed: {e}")
                    raise

    def _classify(self, msg):
        m = msg.lower()
        if "unavailable" in m: return "Unavailable"
        if "timeout"     in m: return "Timeout"
        if "overloaded"  in m: return "Overloaded"
        if "connection"  in m: return "Connection"
        return "Other"

    def get_stats(self):
        return {"total_retries": sum(self.retry_counts.values()), "retries_by_error_type": dict(self.retry_counts)}


# ============================================================================
# CASSANDRA INSERT
# ============================================================================

def insert_rows_into_cassandra(
    session, keyspace, table, rows, cassandra_columns, retry_strategy, batch_size=DEFAULT_BATCH_SIZE,
    col_types: Optional[Dict[str, str]] = None,
    concurrency: int = DEFAULT_CONCURRENT_INSERTS,
    total_inserted_so_far: int = 0,
) -> Tuple[int, int]:
    """
    Insert rows using execute_concurrent_with_args for maximum throughput.

    Sends up to `concurrency` INSERT statements in-flight simultaneously via
    the driver's async pipeline — far faster than serial UNLOGGED BatchStatements
    because the driver overlaps network round-trips across all in-flight requests.

    The `concurrency` parameter should match the number of connections × requests
    per connection in your cluster config (default 100 is a safe starting point).

    Progress is logged after every sub-batch so operators can track transfer rate.
    """
    if not rows:
        return 0, 0

    cassandra_col_set = set(cassandra_columns)
    all_keys = [c for c in cassandra_columns if any(c in row for row in rows) and c in cassandra_col_set]

    if not all_keys:
        logging.warning("No matching Cassandra columns in rows — skipping insert.")
        return 0, len(rows)

    col_list = ", ".join(f'"{c}"' for c in all_keys)
    val_list = ", ".join("?" * len(all_keys))
    cql      = f'INSERT INTO "{keyspace}"."{table}" ({col_list}) VALUES ({val_list})'

    try:
        prepared = session.prepare(cql)
    except Exception as e:
        logging.error(f"Failed to prepare INSERT: {e}")
        raise

    # Build all parameter tuples up front (coercion done once here, not per-retry)
    params_list: List[tuple] = []
    for row in rows:
        values = []
        for c in all_keys:
            val = cassandra_safe(row.get(c))
            if isinstance(val, (dict, list)):
                val = json.dumps(val, ensure_ascii=False, default=str)
            if col_types and c in col_types:
                val = coerce_value_for_cassandra(val, col_types[c])
            values.append(val)
        params_list.append(tuple(values))

    inserted = failed = 0
    total_rows = len(params_list)

    for batch_start in range(0, total_rows, batch_size):
        chunk = params_list[batch_start: batch_start + batch_size]

        def _run_concurrent(c=chunk):
            results = execute_concurrent_with_args(
                session, prepared, c,
                concurrency=concurrency,
                raise_on_first_error=False,
            )
            ok = err = 0
            for success, result_or_exc in results:
                if success:
                    ok += 1
                else:
                    logging.warning(f"Row insert failed: {result_or_exc}")
                    err += 1
            return ok, err

        try:
            ok, err = retry_strategy.execute_with_retry(_run_concurrent, f"insert_batch_{batch_start}")
            inserted += ok
            failed   += err
        except Exception as e:
            logging.error(f"Batch insert failed start={batch_start}: {e}. Skipping {len(chunk)} rows.")
            failed += len(chunk)

        # ── Progress notification ───────────────────────────────────────────
        running_total = total_inserted_so_far + inserted
        logging.info(
            f"  [INSERT PROGRESS] sub-batch {batch_start // batch_size + 1}"
            f" | this_chunk={ok} failed={err}"
            f" | rows transferred so far: {running_total:,}"
        )

    force_gc()
    return inserted, failed


# ============================================================================
# PARAMETER VALIDATION
# ============================================================================

def validate_and_extract_params(params: dict) -> dict:
    required = {
        "ADLS account name":               params.get("adls_account_name"),
        "ADLS file system":                params.get("adls_file_system"),
        "Cassandra contact points":        params.get("cassandra_contact_points"),
        "Cassandra username":              params.get("cassandra_username"),
        "Cassandra keyspace":              params.get("cassandra_keyspace"),
        "Cassandra table":                 params.get("cassandra_table"),
        "Cassandra Key Vault name":        params.get("Cassandra_key_vault_name"),
        "Cassandra Key Vault secret name": params.get("Cassandra_key_vault_secret_name"),
    }
    missing = [k for k, v in required.items() if not v]
    if missing:
        raise ValueError(f"Missing required parameters: {missing}")
    if params.get("truncate_sink_before_write") is None:
        raise ValueError("Missing required parameter: truncate_sink_before_write")

    raw_cp = params["cassandra_contact_points"]
    contact_points = (
        [cp.strip() for cp in raw_cp.split(",") if cp.strip()]
        if isinstance(raw_cp, str) else list(raw_cp)
    )

    def _int(key, default):
        try:
            v = int(params.get(key, default))
            return v if v > 0 else default
        except (ValueError, TypeError):
            return default

    return {
        "adls_account_name":             params["adls_account_name"],
        "adls_file_system":              params["adls_file_system"],
        "adls_directory":                params.get("adls_directory", "").rstrip("/"),
        "cassandra_contact_points":      contact_points,
        "cassandra_port":                _int("cassandra_port", 9042),
        "cassandra_preferred_node":      params.get("cassandra_preferred_node") or None,
        "cassandra_preferred_port":      _int("cassandra_preferred_port", 9042),
        "cassandra_username":            params["cassandra_username"],
        "cassandra_keyspace":            params["cassandra_keyspace"],
        "cassandra_table":               params["cassandra_table"],
        "cassandra_batch_size":          _int("cassandra_batch_size", DEFAULT_BATCH_SIZE),
        "insert_chunk_size":             _int("insert_chunk_size", DEFAULT_INSERT_CHUNK),
        "concurrent_inserts":            _int("concurrent_inserts", DEFAULT_CONCURRENT_INSERTS),
        "key_vault_name":                params["Cassandra_key_vault_name"],
        "key_vault_secret_name":         params["Cassandra_key_vault_secret_name"],
        "truncate_sink_before_write":    bool(params["truncate_sink_before_write"]),
    }


# ============================================================================
# MAIN ACTIVITY FUNCTION
# ============================================================================

@app.activity_trigger(input_name="params")
def process_adls_to_cassandra_activity(params: dict):
    """
    Azure Durable Function activity: un-flatten ADLS CSVs → insert into Cassandra.

    Pipeline
    --------
    1.  Validate params
    2.  Fetch password from Key Vault (Managed Identity); delete from memory
    3.  Connect to Cassandra; verify table exists; get column list
    4.  Optional TRUNCATE
    5.  Connect to ADLS Gen2 (Managed Identity)
    6.  Count parent rows; discover all CSV paths
    7.  Classify paths: scalar CSVs (per jcol) + array CSVs (by depth)
    8.  For each skip/nrows batch of parent rows:
          a. Read parent CSV slice
          b. prepare_batch_parents → partially-nested dicts (_row_rid preserved)
          c. process_batch():
               - scalar CSVs → merge via _row_rid → parent[jcol] = nested_dict
               - array CSVs depth-by-depth → filter by _row_rid (depth 0) or _rid (depth N)
               - assign children → clean metadata
          d. Convert json col dicts → JSON strings  (or keep strings as-is)
          e. insert_rows_into_cassandra UNLOGGED batches
          f. Delete all DataFrames + force GC
    9.  Shutdown Cassandra; final GC
    """
    start_time = datetime.utcnow()
    cluster    = None
    session    = None

    try:
        params = validate_and_extract_params(params)

        # 1. Key Vault
        cassandra_password = get_secret(params["key_vault_name"], params["key_vault_secret_name"])

        # 2. Cassandra
        cluster, session = validate_cassandra_connection(
            contact_points = params["cassandra_contact_points"],
            port           = params["cassandra_port"],
            username       = params["cassandra_username"],
            password       = cassandra_password,
            keyspace       = params["cassandra_keyspace"],
            table          = params["cassandra_table"],
            preferred_node = params["cassandra_preferred_node"],
        )
        del cassandra_password
        force_gc()

        keyspace = params["cassandra_keyspace"]
        table    = params["cassandra_table"]

        cassandra_columns  = get_cassandra_columns(session, keyspace, table)
        cassandra_col_set  = set(cassandra_columns)
        cassandra_col_types = get_cassandra_column_types(session, keyspace, table)
        partition_keys, clustering_keys = get_cassandra_key_columns(session, keyspace, table)
        logging.info(f"Cassandra columns ({len(cassandra_columns)}): {cassandra_columns}")
        logging.info(f"Auto-discovered partition keys: {partition_keys}  clustering keys: {clustering_keys}")

        # 3. Optional TRUNCATE
        if params["truncate_sink_before_write"]:
            logging.info(f"Truncating {keyspace}.{table} …")
            session.execute(f'TRUNCATE "{keyspace}"."{table}"')
            logging.info("TRUNCATE complete.")

        # 4. ADLS
        service_client = validate_adls_connection(params["adls_account_name"], params["adls_file_system"])
        file_system    = params["adls_file_system"]
        export_dir     = (
            f"{params['adls_directory']}/{table}" if params["adls_directory"] else table
        )
        parent_full_path = f"{export_dir}/{table}.csv"

        # 5. Count rows + discover paths
        total_parent_rows = get_csv_row_count(
            service_client, file_system, parent_full_path,
            chunk_size=params["cassandra_batch_size"],
        )
        logging.info(f"Total parent rows: {total_parent_rows}")

        if total_parent_rows == 0:
            return {"status": "success", "message": f"No rows at '{parent_full_path}'.", "rows_inserted": 0}

        all_csv_paths = discover_all_csv_paths(service_client, file_system, export_dir)
        logging.info(f"CSV paths discovered: {len(all_csv_paths)}")
        for p in all_csv_paths:
            logging.info(f"  {p}")

        # 6. Classify paths
        json_col_scalar_paths = get_json_col_scalar_paths(all_csv_paths, export_dir, table)
        csv_info_by_depth     = organize_csv_paths_by_depth(all_csv_paths, export_dir, table)
        json_col_names        = set(json_col_scalar_paths.keys())

        # Pre-compute: for each json column, which depth-0 array names were placed
        # at the document root by _assign_children_to_parents.
        # These must be moved INSIDE doc[jcol] before serialising to JSON string.
        # Only depth-0 arrays are placed at root; deeper arrays are nested inside
        # depth-0 objects by the child assignment step.
        # jcol_root_arrays: arrays that live INSIDE a JSON text column.
        # Their depth-0 CSV has jcol != None, meaning the array was nested inside
        # a JSON column. After reconstruction they sit at doc root and must be
        # moved back inside doc[jcol] before json.dumps().
        jcol_root_arrays: Dict[str, Set[str]] = {}
        for csv_info in csv_info_by_depth.get(0, []):
            if csv_info["jcol"] is not None:   # skip true top-level arrays
                jcol_root_arrays.setdefault(csv_info["jcol"], set()).add(csv_info["arr_name"])

        # top_level_array_cols: arrays that ARE native Cassandra columns (jcol=None).
        # They are stored as JSON text in Cassandra, so they must be serialised to
        # a JSON string, but they stay at the document root — no re-embedding needed.
        top_level_array_cols: Set[str] = set()
        for csv_info in csv_info_by_depth.get(0, []):
            if csv_info["jcol"] is None:
                top_level_array_cols.add(csv_info["arr_name"])

        logging.info(f"JSON column scalar CSVs: {list(json_col_scalar_paths.keys())}")
        logging.info(f"Child array depths: { {d: [x['arr_name'] for x in v] for d, v in csv_info_by_depth.items()} }")
        logging.info(f"jcol_root_arrays (re-embed into JSON col): { {k: list(v) for k, v in jcol_root_arrays.items()} }")
        logging.info(f"top_level_array_cols (stay at root, serialise to JSON): {top_level_array_cols}")

        # 7. Main batch loop
        retry_strategy     = CassandraRetryStrategy()
        batch_size         = params["cassandra_batch_size"]
        concurrent_inserts = params["concurrent_inserts"]
        num_batches        = (total_parent_rows + batch_size - 1) // batch_size
        total_inserted     = 0
        total_failed       = 0
        total_child_rows   = 0

        logging.info(f"Processing {num_batches} batches (concurrent_inserts={concurrent_inserts})")

        for batch_num in range(num_batches):
            skip_rows          = batch_num * batch_size
            current_batch_size = min(batch_size, total_parent_rows - skip_rows)
            batch_label        = f"batch_{batch_num + 1:04d}_of_{num_batches:04d}"
            batch_start_time   = datetime.utcnow()
            logging.info(
                f"[{batch_label}] START {batch_start_time.strftime('%Y-%m-%d %H:%M:%S')} UTC | "
                f"rows {skip_rows}–{skip_rows + current_batch_size - 1}"
            )

            with memory_managed_batch(batch_label):

                # a. Read parent CSV slice
                parent_df = read_csv_from_adls_batched(
                    service_client, file_system, parent_full_path,
                    skip_rows=skip_rows, nrows=current_batch_size,
                )

                # b. Convert to partially-nested parent dicts
                batch_parents = prepare_batch_parents(parent_df)
                release_dataframe(parent_df)

                if not batch_parents:
                    logging.warning(f"[{batch_label}] No parents prepared — skipping.")
                    continue

                logging.info(f"[{batch_label}] {len(batch_parents)} parents prepared")

                # c. Full reconstruction
                documents, child_rows = process_batch(
                    batch_parents         = batch_parents,
                    service_client        = service_client,
                    file_system           = file_system,
                    export_dir            = export_dir,
                    table                 = table,
                    json_col_scalar_paths = json_col_scalar_paths,
                    csv_info_by_depth     = csv_info_by_depth,
                )
                total_child_rows += child_rows
                del batch_parents
                force_gc()

                logging.info(f"[{batch_label}] {len(documents)} docs reconstructed, {child_rows} child rows")

                # d. Serialise + insert documents in small insert_chunks so that
                #    memory is freed progressively rather than holding the entire
                #    reconstructed batch in RAM before any inserts begin.
                #
                #    For each chunk of insert_chunk_size docs:
                #      1. Re-embed jcol arrays (move root-level arrays back into
                #         their owning JSON column dict).
                #      2. Serialise json/array cols to JSON strings.
                #      3. Insert the chunk immediately into Cassandra.
                #      4. Delete the chunk and force GC before moving on.
                inserted = failed = 0
                insert_chunk_size = params["insert_chunk_size"]
                num_docs = len(documents)

                for chunk_start in range(0, num_docs, insert_chunk_size):
                    chunk_docs  = documents[chunk_start : chunk_start + insert_chunk_size]
                    insert_rows: List[Dict] = []

                    for doc in chunk_docs:
                        # Step 1: merge root-level array keys back into their owning jcol dict
                        for jcol, root_arr_names in jcol_root_arrays.items():
                            jcol_dict = doc.get(jcol)
                            if jcol_dict is None:
                                jcol_dict = {}
                                doc[jcol] = jcol_dict
                            if not isinstance(jcol_dict, dict):
                                continue
                            for arr_name in root_arr_names:
                                arr_val = doc.pop(arr_name, None)
                                if arr_val is not None:
                                    jcol_dict[arr_name] = arr_val

                        # Step 2: build the insert row, serialising json/array cols to strings
                        row: Dict[str, Any] = {}
                        for col in cassandra_columns:
                            val = doc.get(col)
                            if val is None:
                                continue
                            if col in json_col_names or col in top_level_array_cols:
                                if isinstance(val, (dict, list)):
                                    row[col] = json.dumps(val, ensure_ascii=False, default=str)
                                elif val is not None:
                                    row[col] = str(val)
                            else:
                                row[col] = val
                        if row:
                            insert_rows.append(row)

                    # Step 3: insert this chunk using concurrent async inserts
                    chunk_inserted, chunk_failed = insert_rows_into_cassandra(
                        session=session, keyspace=keyspace, table=table,
                        rows=insert_rows, cassandra_columns=cassandra_columns,
                        retry_strategy=retry_strategy, batch_size=insert_chunk_size,
                        col_types=cassandra_col_types,
                        concurrency=concurrent_inserts,
                        total_inserted_so_far=total_inserted + inserted,
                    )
                    inserted += chunk_inserted
                    failed   += chunk_failed

                    logging.info(
                        f"[{batch_label}] chunk {chunk_start // insert_chunk_size + 1}: "
                        f"inserted={chunk_inserted} failed={chunk_failed} "
                        f"({chunk_start + len(chunk_docs)}/{num_docs} docs)"
                    )

                    # Step 4: free this chunk before processing the next one
                    del insert_rows, chunk_docs
                    force_gc()

                del documents

            total_inserted += inserted
            total_failed   += failed
            batch_end_time  = datetime.utcnow()
            batch_duration  = (batch_end_time - batch_start_time).total_seconds()
            logging.info(
                f"[{batch_label}] COMPLETE | "
                f"start={batch_start_time.strftime('%Y-%m-%d %H:%M:%S')} UTC  "
                f"end={batch_end_time.strftime('%Y-%m-%d %H:%M:%S')} UTC  "
                f"duration={batch_duration:.2f}s | "
                f"inserted={inserted} failed={failed} child_rows={child_rows} | "
                f"TOTAL ROWS TRANSFERRED SO FAR: {total_inserted:,} / ~{total_parent_rows:,}"
            )

        # 8. Shutdown
        shutdown_cassandra(cluster, session)
        cluster = session = None

        retry_stats = retry_strategy.get_stats()
        duration    = (datetime.utcnow() - start_time).total_seconds()

        return {
            "status":                 "success" if total_failed == 0 else "completed_with_errors",
            "rows_inserted":          total_inserted,
            "message":                total_failed,
            "rows_failed":            total_failed,
            "total_child_rows":       total_child_rows, 
            "json_columns_processed": list(json_col_names),
            "batches_processed":      num_batches,
            "batch_size":             batch_size,
            "truncated_before_write": params["truncate_sink_before_write"],
            "duration_seconds":       round(duration, 2),
            "total_retries":          retry_stats.get("total_retries", 0),
            "retries_by_error_type":  retry_stats.get("retries_by_error_type", {}),
        }

    except Exception as e:
        logging.error(f"Activity failed: {str(e)}", exc_info=True)
        return {"status": "error", "message": str(e)}

    finally:
        if cluster is not None or session is not None:
            shutdown_cassandra(cluster, session)
        force_gc()


# ============================================================================
# ORCHESTRATOR AND HTTP TRIGGER
# ============================================================================

@app.orchestration_trigger(context_name="context")
def adls_to_cassandra_orchestrator(context: df.DurableOrchestrationContext):
    params = context.get_input()
    result = yield context.call_activity("process_adls_to_cassandra_activity", params)
    return result


@app.route(route="ADLS_to_Cassandra_V1", methods=["POST"])
@app.durable_client_input(client_name="client")
async def adls_to_cassandra_http_start(req: func.HttpRequest, client) -> func.HttpResponse:
    """
    HTTP trigger to start the ADLS → Cassandra import orchestration.

    Partition key and clustering key columns are auto-discovered from
    system_schema — no need to specify them in the request body.
    """
    try:
        body = req.get_json()
    except Exception:
        return func.HttpResponse("Invalid JSON body", status_code=400)

    try:
        instance_id = await client.start_new("adls_to_cassandra_orchestrator", None, body)
        return client.create_check_status_response(req, instance_id)
    except Exception as e:
        logging.error(f"HTTP start failed: {str(e)}", exc_info=True)
        return func.HttpResponse(json.dumps({"error": str(e)}), mimetype="application/json", status_code=500)