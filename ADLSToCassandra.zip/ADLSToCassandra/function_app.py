import azure.functions as func
import azure.durable_functions as df
import logging
import json
import uuid
import ast
import gc
from io import StringIO
from typing import Any, Dict
from datetime import datetime

import pandas as pd
from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider
from cassandra.util import Date
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
from azure.storage.filedatalake import DataLakeServiceClient

app = df.DFApp(http_auth_level=func.AuthLevel.ANONYMOUS)

# ============================================================
#            UNFLATTENING HELPERS
# ============================================================

def parse_json_string(value: str) -> Any:
    if not isinstance(value, str):
        return value
    v = value.strip()
    if (v.startswith("[") and v.endswith("]")) or (v.startswith("{") and v.endswith("}")):
        try:
            return json.loads(v)
        except:
            try:
                return ast.literal_eval(v)
            except:
                pass
    return value


def unflatten_dict(flat: Dict[str, Any], sep: str = ".") -> Dict:
    result = {}
    for key, value in flat.items():
        if key in ("_rid", "_parent_rid"):
            continue
        val = parse_json_string(value)
        parts = key.split(sep)
        cur = result
        for i, part in enumerate(parts):
            if i == len(parts) - 1:
                cur[part] = val
            else:
                if part not in cur or not isinstance(cur[part], dict):
                    cur[part] = {}
                cur = cur[part]
    return result


def get_nested_value_dynamic(obj: Any, target_key: str) -> Any:
    if not isinstance(obj, dict):
        return None
    if target_key in obj:
        return obj[target_key]
    for v in obj.values():
        if isinstance(v, dict):
            res = get_nested_value_dynamic(v, target_key)
            if res is not None:
                return res
        elif isinstance(v, list):
            for item in v:
                res = get_nested_value_dynamic(item, target_key)
                if res is not None:
                    return res
    return None


# ============================================================
#            CASSANDRA SCHEMA DISCOVERY
# ============================================================

def get_cassandra_schema(session, keyspace: str, table: str):
    query = """
        SELECT column_name, kind, type
        FROM system_schema.columns
        WHERE keyspace_name=%s AND table_name=%s
        ALLOW FILTERING
    """
    rows = session.execute(query, (keyspace, table))

    partition_keys = []
    column_types = {}

    for r in rows:
        column_types[r.column_name] = r.type
        if r.kind == "partition_key":
            partition_keys.append(r.column_name)

    return partition_keys, column_types


# ============================================================
#            TYPE CASTING ENGINE
# ============================================================

def cast_to_cassandra_type(value, cassandra_type):
    if value is None or value == "":
        return None

    try:
        cassandra_type = cassandra_type.lower()

        if cassandra_type == "uuid":
            return uuid.UUID(value)

        elif cassandra_type in ("int", "varint", "bigint"):
            return int(value)

        elif cassandra_type in ("double", "float", "decimal"):
            return float(value)

        elif cassandra_type == "boolean":
            return str(value).lower() in ("true", "1")

        elif cassandra_type == "timestamp":
            return datetime.fromisoformat(value)

        elif cassandra_type.startswith("list") or cassandra_type.startswith("map"):
            return value

        else:
            return value

    except Exception:
        return value


# ============================================================
#            ACTIVITY FUNCTION
# ============================================================

@app.activity_trigger(input_name="params")
def unflatten_activity(params: Dict):

    cluster = None
    inserted = 0

    acct_name = params["adls_account_name"]
    file_system = params["adls_file_system"]
    source_dir = params["source_directory"].strip("/")
    contact_points = params["cassandra_contact_points"]
    port = int(params["cassandra_port"])
    user = params["cassandra_username"]
    keyspace = params["cassandra_keyspace"]

    table_original = params["cassandra_table"].strip().replace('"', '')
    table_cassandra = table_original.lower()

    batch_size = int(params["adls_batch_size"])

    kv_name = params["Cassandra_key_vault_name"]
    secret_name = params["Cassandra_key_vault_secret_name"]

    try:
        # Azure Identity
        cred = DefaultAzureCredential()
        kv_client = SecretClient(f"https://{kv_name}.vault.azure.net/", cred)
        password = kv_client.get_secret(secret_name).value

        # ADLS
        adls = DataLakeServiceClient(
            f"https://{acct_name}.dfs.core.windows.net", cred
        )
        fs_client = adls.get_file_system_client(file_system)

        # Cassandra
        cluster = Cluster(
            [contact_points],
            port=port,
            auth_provider=PlainTextAuthProvider(user, password)
        )
        session = cluster.connect(keyspace)

        # Schema Discovery
        partition_keys, column_types = get_cassandra_schema(
            session, keyspace, table_cassandra
        )
        valid_columns = set(column_types.keys())

        logging.info(f"Detected Partition Keys: {partition_keys}")

        # Optional truncate
        truncate_requested = str(
            params.get("truncate_sink_before_write", False)
        ).lower() == "true"

        if truncate_requested:
            logging.info(f"Truncating {keyspace}.{table_cassandra}")
            session.execute(f"TRUNCATE {keyspace}.{table_cassandra}")

        # Read CSV
        csv_path = f"{source_dir}/{table_original}/{table_original}.csv"
        file_client = fs_client.get_file_client(csv_path)
        content = file_client.download_file().readall().decode("utf-8")

        main_iterator = pd.read_csv(
            StringIO(content),
            sep="|",
            chunksize=batch_size,
            dtype=str
        )

        for chunk in main_iterator:
            chunk = chunk.fillna("")

            for _, p_row in chunk.iterrows():
                row_dict = p_row.to_dict()
                unflattened_record = unflatten_dict(row_dict)

                # Partition Key Handling
                for pk in partition_keys:
                    val = get_nested_value_dynamic(unflattened_record, pk)
                    if val:
                        unflattened_record[pk] = val
                    else:
                        unflattened_record[pk] = row_dict.get(
                            "_rid", str(uuid.uuid4())
                        )

                cols_to_insert = [
                    c for c in unflattened_record.keys()
                    if c in valid_columns
                ]

                placeholders = ", ".join(["%s"] * len(cols_to_insert))
                stmt = f"""
                    INSERT INTO {table_cassandra}
                    ({', '.join(cols_to_insert)})
                    VALUES ({placeholders})
                """

                values = []
                for c in cols_to_insert:
                    raw_value = unflattened_record[c]
                    cass_type = column_types.get(c)

                    if isinstance(raw_value, (dict, list)):
                        raw_value = json.dumps(raw_value)

                    casted_value = cast_to_cassandra_type(
                        raw_value, cass_type
                    )

                    values.append(casted_value)

                session.execute(stmt, values)
                inserted += 1

            gc.collect()
            logging.info(f"Processed {inserted} records...")

        return {"status": "success", "inserted_rows": inserted,"message":""}

    except Exception as e:
        logging.exception("Ingestion failed")
        return {"status": "error", "message": str(e)}

    finally:
        if cluster:
            cluster.shutdown()


# ============================================================
#            ORCHESTRATOR
# ============================================================

@app.orchestration_trigger(context_name="context")
def unflatten_orchestrator(context: df.DurableOrchestrationContext):
    params = context.get_input()
    result = yield context.call_activity("unflatten_activity", params)
    return result


# ============================================================
#            HTTP STARTER
# ============================================================

@app.route(route="Unflatten_Ingest", methods=["POST"])
@app.durable_client_input(client_name="client")
async def unflatten_http_start(req: func.HttpRequest, client):
    instance_id = await client.start_new(
        "unflatten_orchestrator", None, req.get_json()
    )
    return client.create_check_status_response(req, instance_id)
