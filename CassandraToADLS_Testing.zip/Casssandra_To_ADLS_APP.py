import azure.functions as func
import azure.durable_functions as df
import logging
import json
import pandas as pd
import uuid
import time
from datetime import datetime
from io import StringIO
from collections import deque
from typing import Dict, Any, List, Tuple, Optional

from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider
from azure.storage.filedatalake import DataLakeServiceClient

app = df.DFApp(http_auth_level=func.AuthLevel.ANONYMOUS)


# -------------------------
# Utilities
# -------------------------
def normalize_block_path(path: str) -> str:
    if not path:
        return ""
    parts = [p for p in path.split(".") if p]
    cleaned = []
    for p in parts:
        if not cleaned or cleaned[-1] != p:
            cleaned.append(p)
    parts = cleaned
    changed = True
    while changed:
        changed = False
        n = len(parts)
        for block_len in range(n // 2, 0, -1):
            i = 0
            while i + 2 * block_len <= len(parts):
                if parts[i:i + block_len] == parts[i + block_len:i + 2 * block_len]:
                    del parts[i + block_len:i + 2 * block_len]
                    changed = True
                    break
                i += 1
            if changed:
                break
    return ".".join(parts)


def flatten_no_arrays(d: Dict[str, Any], parent: str = "") -> Dict[str, Any]:
    flat: Dict[str, Any] = {}
    for k, v in d.items():
        key = f"{parent}.{k}" if parent else k
        if isinstance(v, dict):
            flat.update(flatten_no_arrays(v, key))
        else:
            flat[key] = v
    return flat


def clean_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame()
    def fix(v):
        if v is None:
            return None
        if isinstance(v, (str, int, float, bool)):
            return v
        if isinstance(v, list):
            return v if all(not isinstance(x, dict) for x in v) else None
        if isinstance(v, dict):
            return None
        try:
            return str(v)
        except:
            return None
    for col in df.columns:
        df[col] = df[col].apply(fix)
    return df


def upload_csv_to_adls(service_client, file_system: str, directory: str, file_name: str, df: pd.DataFrame):
    df = clean_dataframe(df)
    if df is None or df.empty:
        logging.info(f"Skipping empty file: {directory}/{file_name}")
        return
    fs = service_client.get_file_system_client(file_system)
    if directory:
        curr = ""
        for seg in directory.strip("/").split("/"):
            curr = f"{curr}/{seg}" if curr else seg
            try:
                fs.get_directory_client(curr).create_directory()
            except Exception:
                pass
    dclient = fs.get_directory_client(directory)
    try:
        dclient.get_file_client(file_name).delete_file()
    except Exception:
        pass
    df_out = df.copy()
    for col in df_out.columns:
        df_out[col] = df_out[col].apply(lambda v: json.dumps(v, ensure_ascii=False) if isinstance(v, list) else ("" if v is None else v))
    buf = StringIO()
    df_out.to_csv(buf, index=False, sep="|")
    data = buf.getvalue().encode("utf-8")
    fc = dclient.create_file(file_name)
    fc.append_data(data, offset=0, length=len(data))
    fc.flush_data(len(data))
    logging.info(f"Uploaded: {directory}/{file_name}")


# -------------------------
# Cosmos-style iterative extractor (optimized)
# -------------------------
def extract_arrays_iterative_optimized(doc: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, pd.DataFrame]]:
    parent_fields: Dict[str, Any] = {}
    child_tables: Dict[str, List[pd.DataFrame]] = {}
    root_rid = doc.get("_rid") or str(uuid.uuid4())
    doc["_rid"] = root_rid
    def flatten_keep_lists(d: Dict[str, Any], parent=""):
        flat = {}
        for k, v in d.items():
            key = f"{parent}.{k}" if parent else k
            if isinstance(v, list):
                flat[key] = v
            elif isinstance(v, dict):
                flat.update(flatten_keep_lists(v, key))
            else:
                flat[key] = v
        return flat
    flat_root = flatten_keep_lists(doc)
    queue = deque()
    for key, value in flat_root.items():
        if not isinstance(value, list):
            parent_fields[key] = value
            continue
        primitive_items = [v for v in value if not isinstance(v, dict) and not isinstance(v, list)]
        dict_items = [v for v in value if isinstance(v, dict)]
        list_items = [v for v in value if isinstance(v, list)]
        if primitive_items and not dict_items and not list_items:
            parent_fields[key] = value
            continue
        # array-of-dicts -> queue as child rows (table name uses full dotted path)
        for item in dict_items:
            item["_rid"] = str(uuid.uuid4())
            item["_parent_rid"] = root_rid
            table_name = key  # full dotted path
            queue.append((item, table_name, root_rid))
        # array-of-arrays -> treat inner lists: if inner contains dicts, enqueue; else primitives -> parent
        for inner in list_items:
            inner_dicts = [x for x in inner if isinstance(x, dict)]
            inner_prims = [x for x in inner if not isinstance(x, dict)]
            if inner_prims and not inner_dicts:
                parent_fields[key] = value
            else:
                for itm in inner_dicts:
                    itm["_rid"] = str(uuid.uuid4())
                    itm["_parent_rid"] = root_rid
                    inner_table = f"{key}.inner"
                    queue.append((itm, inner_table, root_rid))
    batch_size = 100
    current_batch: Dict[str, List[Dict[str, Any]]] = {}
    while queue:
        current, table_name, parent_rid = queue.popleft()
        flat_child = flatten_keep_lists(current)
        row = {"_rid": current["_rid"], "_parent_rid": parent_rid}
        for k, v in flat_child.items():
            if not isinstance(v, list):
                # keep final field name only (child row)
                field_name = k.split(".")[-1] if "." in k else k
                row[field_name] = v
                continue
            primitive_items = [x for x in v if not isinstance(x, dict) and not isinstance(x, list)]
            dict_items = [x for x in v if isinstance(x, dict)]
            list_items = [x for x in v if isinstance(x, list)]
            if primitive_items and not dict_items and not list_items:
                field_name = k.split(".")[-1] if "." in k else k
                row[field_name] = v
                continue
            for itm in dict_items:
                itm["_rid"] = str(uuid.uuid4())
                itm["_parent_rid"] = current["_rid"]
                nested_table = f"{table_name}.{k.split('.')[-1] if '.' in k else k}"
                queue.append((itm, nested_table, current["_rid"]))
            for inner in list_items:
                inner_dicts = [x for x in inner if isinstance(x, dict)]
                inner_prims = [x for x in inner if not isinstance(x, dict)]
                if inner_prims and not inner_dicts:
                    field_name = k.split(".")[-1] if "." in k else k
                    row[field_name] = v
                else:
                    for itm in inner_dicts:
                        itm["_rid"] = str(uuid.uuid4())
                        itm["_parent_rid"] = current["_rid"]
                        nested_table = f"{table_name}.{k.split('.')[-1] if '.' in k else k}.inner"
                        queue.append((itm, nested_table, current["_rid"]))
        if table_name not in current_batch:
            current_batch[table_name] = []
        current_batch[table_name].append(row)
        if len(current_batch.get(table_name, [])) >= batch_size:
            if table_name not in child_tables:
                child_tables[table_name] = []
            child_tables[table_name].append(pd.DataFrame(current_batch[table_name]))
            current_batch[table_name] = []
    for tbl, rows in current_batch.items():
        if rows:
            if tbl not in child_tables:
                child_tables[tbl] = []
            child_tables[tbl].append(pd.DataFrame(rows))
    final_children: Dict[str, pd.DataFrame] = {}
    for k, v in child_tables.items():
        try:
            final_children[k] = pd.concat(v, ignore_index=True)
        except ValueError:
            final_children[k] = pd.DataFrame(v)
    return parent_fields, final_children


# -------------------------
# JSON detection helpers
# -------------------------
def is_json_like(val) -> bool:
    if isinstance(val, (dict, list)):
        return True
    if isinstance(val, (bytes, bytearray)):
        try:
            _ = val.decode()
            return True
        except Exception:
            return False
    if isinstance(val, str):
        try:
            parsed = json.loads(val)
            return isinstance(parsed, (dict, list))
        except Exception:
            return False
    return False


def detect_json_column(rows) -> Optional[str]:
    if not rows:
        return None
    sample = rows[:20]
    cols = rows[0]._asdict().keys()
    for col in cols:
        for r in sample:
            try:
                if is_json_like(r._asdict().get(col)):
                    return col
            except Exception:
                continue
    return None


# -------------------------
# Activity: Cassandra flatten -> ADLS
# -------------------------
@app.activity_trigger(input_name="params")
def cassandra_flatten_activity(params: dict):
    start = datetime.utcnow()
    try:
        hosts_param = params.get("cassandra_contact_points")
        if isinstance(hosts_param, str):
            hosts = [x.strip() for x in hosts_param.split(",") if x.strip()]
        elif isinstance(hosts_param, list):
            hosts = hosts_param
        else:
            hosts = []

        preferred_node = params.get("cassandra_preferred_node") or None
        if preferred_node:
            hosts = [preferred_node]

        port = int(params.get("cassandra_port", 9042))
        ks = params["cassandra_keyspace"]
        table = params["cassandra_table"]
        cass_user = params.get("cassandra_username")
        cass_pass = params.get("cassandra_password")

        auth = PlainTextAuthProvider(cass_user, cass_pass) if cass_user and cass_pass else None
        cluster = Cluster(hosts, port=port, auth_provider=auth)
        session = cluster.connect()

        # Read all rows from the table
        rows = list(session.execute(f"SELECT * FROM {ks}.{table}"))
        if not rows:
            try:
                session.shutdown()
                cluster.shutdown()
            except Exception:
                pass
            return {"status": "success", "message": "No rows found", "docs_processed": 0}

        json_col = detect_json_column(rows)
        parents = []
        all_children: Dict[str, List[pd.DataFrame]] = {}

        for r in rows:
            rd = r._asdict()
            raw_json = rd.get(json_col)
            if isinstance(raw_json, (bytes, bytearray)):
                raw_json = raw_json.decode("utf-8", "ignore")
            try:
                parsed = json.loads(raw_json) if isinstance(raw_json, str) else raw_json or {}
            except Exception:
                parsed = {}

            parent_json, child_json = extract_arrays_iterative_optimized(parsed)

            # prefix parent json keys with json_col
            final_row = {}
            for k, v in parent_json.items():
                fk = f"{json_col}.{normalize_block_path(k)}"
                final_row[fk] = v

            # include normal cassandra columns
            for c, val in rd.items():
                if c != json_col:
                    final_row[c] = val

            parents.append(final_row)

            # collect children, avoid double prefix
            for name, df in child_json.items():
                clean = normalize_block_path(name)
                if clean.startswith(f"{json_col}."):
                    nm = clean
                else:
                    nm = f"{json_col}.{clean}"
                all_children.setdefault(nm, []).append(df)

        parent_df = pd.DataFrame(parents)

        # prepare ADLS client
        adls_account = params["adls_account_name"]
        adls_key = params["adls_account_key"]
        adls_fs = params["adls_file_system"]
        adls_dir = params.get("adls_directory", "").strip("/")

        service_client = DataLakeServiceClient(
            account_url=f"https://{adls_account}.dfs.core.windows.net",
            credential=adls_key
        )

        export_dir = f"{adls_dir}/{table}" if adls_dir else table
        # upload parent
        upload_csv_to_adls(service_client, adls_fs, export_dir, f"{table}.csv", parent_df)

        # upload children - folder path uses full dotted path
        uploaded = 0
        for p, dfs in all_children.items():
            merged = pd.concat(dfs, ignore_index=True)
            normalized = normalize_block_path(p)
            parts = normalized.split(".") if normalized else [normalized]
            folder = "/".join(parts)
            fname = f"{parts[-1]}.csv"
            upload_csv_to_adls(service_client, adls_fs, f"{export_dir}/{folder}", fname, merged)
            uploaded += 1

        try:
            session.shutdown()
            cluster.shutdown()
        except Exception:
            pass

        end = datetime.utcnow()
        duration = (end - start).total_seconds()
        return {
            "status": "success",
            "docs_processed": len(parents),
            "parent_rows": len(parent_df),
            "child_tables_created": len(all_children),
            "child_tables_uploaded": uploaded,
            "duration_seconds": duration
        }

    except Exception as e:
        logging.exception("cassandra_flatten_activity")
        return {"status": "error", "message": str(e)}


# -------------------------
# Orchestrator & HTTP starter
# -------------------------
@app.orchestration_trigger(context_name="context")
def cassandra_flatten_orchestrator(context: df.DurableOrchestrationContext):
    params = context.get_input()
    result = yield context.call_activity("cassandra_flatten_activity", params)
    return result


@app.route(route="Cassandra_to_ADLS_Flatten", methods=["POST"])
@app.durable_client_input(client_name="client")
async def cassandra_flatten_http_start(req: func.HttpRequest, client):
    try:
        body = req.get_json()
        instance_id = await client.start_new("cassandra_flatten_orchestrator", None, body)
        return client.create_check_status_response(req, instance_id)
    except Exception as e:
        logging.exception("cassandra_flatten_http_start")
        return func.HttpResponse(str(e), status_code=500)
