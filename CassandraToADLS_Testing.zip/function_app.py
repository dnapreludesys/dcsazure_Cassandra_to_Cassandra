import azure.functions as func
import azure.durable_functions as df
import logging
import json
import pandas as pd
import uuid
from datetime import datetime
from io import StringIO
from collections import deque
from typing import Dict, Any, List, Tuple, Optional

from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider
from azure.storage.filedatalake import DataLakeServiceClient

app = df.DFApp(http_auth_level=func.AuthLevel.ANONYMOUS)

# ------------------------------------------------------------
# Utility helpers
# ------------------------------------------------------------
def normalize_block_path(path: str) -> str:
    if not path:
        return ""
    parts = [p for p in path.split(".") if p]
    cleaned = []
    for p in parts:
        if not cleaned or cleaned[-1] != p:
            cleaned.append(p)
    return ".".join(cleaned)


def flatten_keep_lists(d: Dict[str, Any], parent="") -> Dict[str, Any]:
    flat = {}
    for k, v in d.items():
        key = f"{parent}.{k}" if parent else k
        if isinstance(v, list):
            flat[key] = v
        elif isinstance(v, dict):
            flat.update(flatten_keep_lists(v, key))
        else:
            flat[key] = v
    return flat


def clean_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame()

    def fix(v):
        if v is None:
            return None
        if isinstance(v, (str, int, float, bool)):
            return v
        if isinstance(v, list):
            return v if all(not isinstance(x, dict) for x in v) else None
        if isinstance(v, dict):
            return None
        try:
            return str(v)
        except Exception:
            return None

    for col in df.columns:
        df[col] = df[col].apply(fix)
    return df


def upload_csv_to_adls(client, file_system, directory, file_name, df):
    df = clean_dataframe(df)
    if df.empty:
        return

    fs = client.get_file_system_client(file_system)

    if directory:
        curr = ""
        for seg in directory.strip("/").split("/"):
            curr = f"{curr}/{seg}" if curr else seg
            try:
                fs.get_directory_client(curr).create_directory()
            except Exception:
                pass

    dclient = fs.get_directory_client(directory)
    try:
        dclient.get_file_client(file_name).delete_file()
    except Exception:
        pass

    df_out = df.copy()
    for col in df_out.columns:
        df_out[col] = df_out[col].apply(
            lambda v: json.dumps(v, ensure_ascii=False)
            if isinstance(v, list) else ("" if v is None else v)
        )

    buf = StringIO()
    df_out.to_csv(buf, index=False, sep="|")
    content = buf.getvalue().encode("utf-8")

    fclient = dclient.create_file(file_name)
    fclient.append_data(content, 0, len(content))
    fclient.flush_data(len(content))


# ------------------------------------------------------------
# Cosmos-style multi-array flattening (CORE LOGIC)
# ------------------------------------------------------------
def extract_arrays_iterative_optimized(doc: Dict[str, Any]) -> Tuple[Dict, Dict]:
    parent = {}
    children = {}

    root_rid = str(uuid.uuid4())
    doc["_rid"] = root_rid

    flat_root = flatten_keep_lists(doc)
    queue = deque()

    for key, value in flat_root.items():
        if not isinstance(value, list):
            parent[key] = value
            continue

        dict_items = [v for v in value if isinstance(v, dict)]
        prim_items = [v for v in value if not isinstance(v, dict)]

        if prim_items and not dict_items:
            parent[key] = value
            continue

        for item in dict_items:
            item["_rid"] = str(uuid.uuid4())
            item["_parent_rid"] = root_rid
            queue.append((item, key, root_rid))

    while queue:
        current, table_name, parent_rid = queue.popleft()
        flat_child = flatten_keep_lists(current)

        row = {"_rid": current["_rid"], "_parent_rid": parent_rid}

        for k, v in flat_child.items():
            col = k.split(".")[-1]
            if not isinstance(v, list):
                row[col] = v
                continue

            dict_items = [x for x in v if isinstance(x, dict)]
            prim_items = [x for x in v if not isinstance(x, dict)]

            if prim_items and not dict_items:
                row[col] = v
                continue

            for itm in dict_items:
                itm["_rid"] = str(uuid.uuid4())
                itm["_parent_rid"] = current["_rid"]
                queue.append((itm, f"{table_name}.{col}", current["_rid"]))

        children.setdefault(table_name, []).append(pd.DataFrame([row]))

    merged = {k: pd.concat(v, ignore_index=True) for k, v in children.items()}
    return parent, merged


# ------------------------------------------------------------
# JSON auto-detection
# ------------------------------------------------------------
def is_json_like(val) -> bool:
    if isinstance(val, (dict, list)):
        return True
    if isinstance(val, (bytes, bytearray)):
        try:
            val.decode()
            return True
        except Exception:
            return False
    if isinstance(val, str):
        try:
            parsed = json.loads(val)
            return isinstance(parsed, (dict, list))
        except Exception:
            return False
    return False


def detect_json_column(rows) -> Optional[str]:
    for col in rows[0]._asdict().keys():
        for r in rows[:20]:
            if is_json_like(r._asdict().get(col)):
                return col
    return None


# ------------------------------------------------------------
# ACTIVITY FUNCTION
# ------------------------------------------------------------
@app.activity_trigger(input_name="params")
def cassandra_flatten_activity(params: dict):
    start = datetime.utcnow()

    try:
        hosts = params["cassandra_contact_points"]
        if isinstance(hosts, str):
            hosts = [h.strip() for h in hosts.split(",") if h.strip()]

        preferred = params.get("cassandra_preferred_node")
        if preferred:
            hosts = [preferred]

        port = int(params.get("cassandra_port", 9042))
        auth = PlainTextAuthProvider(
            params.get("cassandra_username"),
            params.get("cassandra_password")
        )

        ks = params["cassandra_keyspace"]
        table = params["cassandra_table"]

        pk = params.get("cassandra_partition_key", "").strip()
        pk_vals = params.get("cassandra_partition_key_value", [])

        if isinstance(pk_vals, str):
            pk_vals = [v.strip() for v in pk_vals.split(",") if v.strip()]

        if pk and pk_vals:
            in_clause = ",".join(f"'{v}'" for v in pk_vals)
            query = f"SELECT * FROM {ks}.{table} WHERE {pk} IN ({in_clause}) ALLOW FILTERING"
        else:
            query = f"SELECT * FROM {ks}.{table}"

        cluster = Cluster(hosts, port=port, auth_provider=auth)
        session = cluster.connect()

        rows = list(session.execute(query))
        if not rows:
            return {"status": "success", "docs_processed": 0}

        json_col = detect_json_column(rows)

        parents, children = [], {}

        for r in rows:
            rd = r._asdict()
            raw = rd.get(json_col)

            if isinstance(raw, (bytes, bytearray)):
                raw = raw.decode("utf-8", "ignore")

            try:
                parsed = json.loads(raw) if isinstance(raw, str) else raw or {}
            except Exception:
                parsed = {}

            p, c = extract_arrays_iterative_optimized(parsed)

            row = {f"{json_col}.{normalize_block_path(k)}": v for k, v in p.items()}
            for col, val in rd.items():
                if col != json_col:
                    row[col] = val
            parents.append(row)

            for name, df in c.items():
                nm = f"{json_col}.{normalize_block_path(name)}"
                children.setdefault(nm, []).append(df)

        parent_df = pd.DataFrame(parents)

        adls = DataLakeServiceClient(
            account_url=f"https://{params['adls_account_name']}.dfs.core.windows.net",
            credential=params["adls_account_key"]
        )

        base = params.get("adls_directory", "").strip("/")
        export_dir = f"{base}/{table}" if base else table

        upload_csv_to_adls(adls, params["adls_file_system"], export_dir, f"{table}.csv", parent_df)

        for p, dfs in children.items():
            merged = pd.concat(dfs, ignore_index=True)
            parts = p.split(".")
            upload_csv_to_adls(
                adls,
                params["adls_file_system"],
                f"{export_dir}/{'/'.join(parts)}",
                f"{parts[-1]}.csv",
                merged
            )

        session.shutdown()
        cluster.shutdown()

        return {
            "status": "success",
            "parent_rows": len(parent_df),
            "child_tables": len(children),
            "duration_seconds": (datetime.utcnow() - start).total_seconds()
        }

    except Exception as e:
        logging.exception("Flatten failed")
        return {"status": "error", "message": str(e)}


# ------------------------------------------------------------
# ORCHESTRATOR (FIXED)
# ------------------------------------------------------------
@app.orchestration_trigger(context_name="context")
def cassandra_flatten_orchestrator(context: df.DurableOrchestrationContext):
    result = yield context.call_activity(
        "cassandra_flatten_activity",
        context.get_input()
    )
    return result


# ------------------------------------------------------------
# HTTP STARTER
# ------------------------------------------------------------
@app.route(route="Cassandra_to_ADLS_Flatten", methods=["POST"])
@app.durable_client_input(client_name="client")
async def cassandra_flatten_http_start(req: func.HttpRequest, client):
    instance_id = await client.start_new(
        "cassandra_flatten_orchestrator",
        None,
        req.get_json()
    )
    return client.create_check_status_response(req, instance_id)
